local mposx = 0;
local mposy = 0;
local hovered = nil;
local buttonWidth = 250;
local buttonHeight = 75;
local buttonBorder = 2;
local label = -1;
gfx.GradientColors(0,128,255,255,0,128,255,0)
local gradient = gfx.LinearGradient(0,0,0,1)

mouse_clipped = function(x,y,w,h)
    return mposx > x and mposy > y and mposx < x+w and mposy < y+h;
end;

draw_button = function(name, x, y, hoverindex)
    local rx = x - (buttonWidth / 2);
    local ty = y - (buttonHeight / 2);
    gfx.BeginPath();
    gfx.FillColor(0,128,255);
    if name == "EXIT" then
        gfx.FillColor(255,55,55);
    end

    if mouse_clipped(rx,ty, buttonWidth, buttonHeight) then
       hovered = hoverindex;
       gfx.FillColor(255,128,0);
    end
    gfx.Rect(rx - buttonBorder,
        ty - buttonBorder,
        buttonWidth + (buttonBorder * 2),
        buttonHeight + (buttonBorder * 2));
    gfx.Fill();
    gfx.BeginPath();
    gfx.FillColor(40,40,40);
    gfx.Rect(rx, ty, buttonWidth, buttonHeight);
    gfx.Fill();
    gfx.BeginPath();
    gfx.FillColor(255,255,255);
    gfx.TextAlign(gfx.TEXT_ALIGN_CENTER + gfx.TEXT_ALIGN_MIDDLE);
    gfx.FontSize(40);
    gfx.Text(name, x, y);
end;

render = function(deltaTime)
    resx,resy = game.GetResolution();
    mposx,mposy = game.GetMousePos();
    gfx.Scale(resx, resy / 3)
    gfx.Rect(0,0,1,1)
    gfx.FillPaint(gradient)
    gfx.Fill()
    gfx.ResetTransform()
    gfx.BeginPath()
    buttonY = resy / 2;
    hovered = nil;
    gfx.LoadSkinFont("segoeui.ttf");
    draw_button("SINGLEPLAYER", resx / 2 - buttonWidth / 2 - 10, buttonY, Menu.Start);
    draw_button("MULTIPLAYER", resx / 2 + buttonWidth / 2 + 10, buttonY, Menu.Multiplayer);
    buttonY = buttonY + 100;
    draw_button("GET SONGS", resx / 2 - buttonWidth / 2 - 10, buttonY, Menu.DLScreen);
    draw_button("SETTINGS", resx / 2 + buttonWidth / 2 + 10, buttonY, Menu.Settings);
    buttonY = buttonY + 100;
    draw_button("EXIT", resx / 2, buttonY, Menu.Exit);
    gfx.BeginPath();
    gfx.FillColor(255,255,255);
    gfx.FontSize(120);
    if label == -1 then
        gfx.LoadSkinFont("segoeuil.ttf");
        label = gfx.CreateLabel("unnamed_sdvx_clone", 36, 0);
        label3 = gfx.CreateLabel("by fdigl - Test Release 1 build 2", 16, 0);
        label4 = gfx.CreateLabel("http://laserga.me/", 16, 0);
        gfx.LoadSkinFont("segoeuib.ttf");
        label2 = gfx.CreateLabel("LASERGAME", 120, 0);
    end
    gfx.TextAlign(gfx.TEXT_ALIGN_CENTER + gfx.TEXT_ALIGN_MIDDLE);
    gfx.DrawLabel(label, resx / 2, resy / 2 - 280, resx-40);
    gfx.DrawLabel(label2, resx / 2, resy / 2 - 200, resx-40);
    gfx.DrawLabel(label3, resx / 2, resy / 2 - 125, resx-40);
    gfx.DrawLabel(label4, resx / 2, resy / 2 - 100, resx-40);
    updateUrl, updateVersion = game.UpdateAvailable()
    if updateUrl then
       gfx.BeginPath()
       gfx.TextAlign(gfx.TEXT_ALIGN_BOTTOM + gfx.TEXT_ALIGN_LEFT)
       gfx.FontSize(30)
       gfx.Text(string.format("Version %s is now available", updateVersion), 5, resy - buttonHeight - 10)
       draw_button("VIEW", buttonWidth / 2 + 5, resy - buttonHeight / 2 - 5, 4);
    end
end;

mouse_pressed = function(button)
    if hovered then
        hovered()
    end
    return 0
end
