local RECT_FILL = "fill"
local RECT_STROKE = "stroke"
local RECT_FILL_STROKE = RECT_FILL .. RECT_STROKE

gfx._ImageAlpha = 1

gfx._FillColor = gfx.FillColor
gfx._StrokeColor = gfx.StrokeColor
gfx._SetImageTint = gfx.SetImageTint


gfx.SetImageTint = nil

function gfx.FillColor(r, g, b, a)
    r = math.floor(r or 255)
    g = math.floor(g or 255)
    b = math.floor(b or 255)
    a = math.floor(a or 255)

    gfx._ImageAlpha = a / 255
    gfx._FillColor(r, g, b, a)
    gfx._SetImageTint(r, g, b)
end

function gfx.StrokeColor(r, g, b)
    r = math.floor(r or 255)
    g = math.floor(g or 255)
    b = math.floor(b or 255)

    gfx._StrokeColor(r, g, b)
end

function gfx.DrawRect(kind, x, y, w, h)
    local doFill = kind == RECT_FILL or kind == RECT_FILL_STROKE
    local doStroke = kind == RECT_STROKE or kind == RECT_FILL_STROKE

    local doImage = not (doFill or doStroke)

    gfx.BeginPath()

    if doImage then
        gfx.ImageRect(x, y, w, h, kind, gfx._ImageAlpha, 0)
    else
        gfx.Rect(x, y, w, h)
        if doFill then gfx.Fill() end
        if doStroke then gfx.Stroke() end
    end
end

local buttonStates = { }
local buttonsInOrder = {
    game.BUTTON_BTA,
    game.BUTTON_BTB,
    game.BUTTON_BTC,
    game.BUTTON_BTD,
    
    game.BUTTON_FXL,
    game.BUTTON_FXR,

    game.BUTTON_STA,
}

function UpdateButtonStatesAfterProcessed()
    for i = 1, 6 do
        local button = buttonsInOrder[i]
        buttonStates[button] = game.GetButton(button)
    end
end

game.GetButtonPressed = function(button)
    return game.GetButton(button) and not buttonStates[button]
end
                                         
local resx, resy 
local portrait 
local desw, desh 
local scale 

local jacketFallback = gfx.CreateSkinImage("song_select/loading.png", 0)
local bottomFill = gfx.CreateSkinImage("console/console.png", 0)
local topFill = gfx.CreateSkinImage("fill_top.png", 0)
local critAnim = gfx.CreateSkinImage("crit_anim.png", 0)
local critCap = gfx.CreateSkinImage("crit_cap.png", 0)
local critCapBack = gfx.CreateSkinImage("crit_cap_back.png", 0)
local laserCursor = gfx.CreateSkinImage("pointer.png", 0)
local laserCursorOverlay = gfx.CreateSkinImage("pointer_overlay.png", 0)
local alertLeft = gfx.CreateSkinImage("alert_l.png",0)
local alertRight = gfx.CreateSkinImage("alert_r.png",0)

local ioConsoleDetails = {
    gfx.CreateSkinImage("console/detail_left.png", 0),
    gfx.CreateSkinImage("console/detail_right.png", 0),
}

local consoleAnimImages = {
    gfx.CreateSkinImage("console/glow_bta.png", 0),
    gfx.CreateSkinImage("console/glow_btb.png", 0),
    gfx.CreateSkinImage("console/glow_btc.png", 0),
    gfx.CreateSkinImage("console/glow_btd.png", 0),
    
    gfx.CreateSkinImage("console/glow_fxl.png", 0),
    gfx.CreateSkinImage("console/glow_fxr.png", 0),

    gfx.CreateSkinImage("console/glow_voll.png", 0),
    gfx.CreateSkinImage("console/glow_volr.png", 0),
}

local introTimer = 2
local outroTimer = 0

local alertTimers = {-2,-2}

local earlateTimer = 0
local earlateColors = { {255,255,0}, {0,255,255} }

local critAnimTimer = 0

local consoleAnimSpeed = 10
local consoleAnimTimers = { 0, 0, 0, 0, 0, 0, 0, 0 }

local score = 0
local combo = 0
local comboTimer = 0;
local jacket = nil
local critLinePos = { 0.95, 0.73 };
local songInfoWidth = 400
local jacketWidth = 100
local comboScale = 1.0
local late = false
local title = nil
local artist = nil
local diffNames = {"NOV", "ADV", "EXH", "INF"}
local clearTexts = {"TRACK CRASH", "TRACK COMPLETE", "TRACK COMPLETE", "ULTIMATE CHAIN", "PERFECT" }

game.LoadSkinSample("bleep")

-- PLAYERDEFS
local useAlertSDVX = true -- toggles between SDVX (no custom color support) and default laser alerts
local showEarlate = "normal" -- valid: hidden, low, normal, high, higher
local earLateDisplay = "medium" -- valid: low, medium, high, opaque
local uninterruptedCombo = "SDVX" -- valid: USC, SDVX, none
local burstCombo = false -- emphasizes combo size every 100 notes like in SDVX
local staticCombo = true -- toggles combo size increase on note hit
local opaqueCombo = false -- toggles full opacity of combo counter
local showScoreReplay = false -- toggle score replay display
local doRenderGaugePercent = true --toggles gauge percentage display
local doRenderMaxCombo = true -- toggles max chain counter on bottom left
                                      
function IsUserInputActive(lane)
    if lane < 7 then
        return game.GetButton(buttonsInOrder[lane])
    end
    return gameplay.IsLaserHeld(lane - 7)
end
                                           
function SetFillToLaserColor(index, alpha)
    alpha = math.floor(alpha or 255)
    local r, g, b = game.GetLaserColor(index - 1)
    gfx.FillColor(r, g, b, alpha)
end
                               
function ResetLayoutInformation()
    resx, resy = game.GetResolution()
    portrait = resy > resx
    desw = portrait and 720 or 1280 
    desh = desw * (resy / resx)
    scale = resx / desw
end
                                  
function render(deltaTime) 
    gfx.ResetTransform()

    if introTimer > 0 then
        gfx.FillColor(0, 0, 0, math.floor(255 * math.min(introTimer, 1)))
        gfx.DrawRect(RECT_FILL, 0, 0, resx, resy)
    end
    
    gfx.Scale(scale, scale)
    local yshift = 0

    if portrait then yshift = DrawBanner(deltaTime) end

    gfx.Translate(0, yshift - 150 * math.max(introTimer - 1, 0))
    drawSongInfo(deltaTime)
    drawScore(deltaTime)
    gfx.Translate(0, -yshift + 150 * math.max(introTimer - 1, 0))
    drawGauge(deltaTime)
    drawEarlate(deltaTime)
    drawCombo(deltaTime)
    drawAlerts(deltaTime)
end
                                           
function SetUpCritTransform()
    gfx.ResetTransform()
    
    gfx.Translate(gameplay.critLine.x, gameplay.critLine.y)
    gfx.Rotate(-gameplay.critLine.rotation)
end

function GetCritLineCenteringOffset()
    local distFromCenter = resx / 2 - gameplay.critLine.x
    local dvx = math.cos(gameplay.critLine.rotation)
    local dvy = math.sin(gameplay.critLine.rotation)
    return math.sqrt(dvx * dvx + dvy * dvy) * distFromCenter
end

function render_crit_base(deltaTime)
    ResetLayoutInformation()

    critAnimTimer = critAnimTimer + deltaTime
    SetUpCritTransform()
    
    local xOffset = GetCritLineCenteringOffset()
    gfx.Translate(xOffset, 0)
    
    gfx.FillColor(0, 0, 0, 200)
    gfx.DrawRect(RECT_FILL, -resx, 0, resx * 2, resy)

    local critWidth = resx * (portrait and 1 or 0.8)
    
    local clw, clh = gfx.ImageSize(critAnim)
    local critAnimHeight = 20 * scale
    local critAnimWidth = critAnimHeight * (clw / clh)

    local ccw, cch = gfx.ImageSize(critCap)
    local critCapHeight = critAnimHeight * (cch / clh)
    local critCapWidth = critCapHeight * (ccw / cch)

    do
        gfx.FillColor(255, 255, 255)
        
        gfx.DrawRect(critCapBack, -critWidth / 2 - critCapWidth / 2, -critCapHeight / 2, critCapWidth, critCapHeight)
        gfx.Scale(-1, 1) 
        
        gfx.DrawRect(critCapBack, -critWidth / 2 - critCapWidth / 2, -critCapHeight / 2, critCapWidth, critCapHeight)
        gfx.Scale(-1, 1) 
    end
    
    do
        local numPieces = 1 + math.ceil(critWidth / (critAnimWidth * 2))
        local startOffset = critAnimWidth * ((critAnimTimer * 0.5) % 1)

        gfx.Scissor(-critWidth / 2, -critAnimHeight / 2, critWidth / 2, critAnimHeight)
        for i = 1, numPieces do
            gfx.DrawRect(critAnim, -startOffset - critAnimWidth * (i - 1), -critAnimHeight / 2, critAnimWidth, critAnimHeight)
        end
        gfx.ResetScissor()

        gfx.Scissor(0, -critAnimHeight / 2, critWidth / 2, critAnimHeight)
        for i = 1, numPieces do
            gfx.DrawRect(critAnim, -critAnimWidth + startOffset + critAnimWidth * (i - 1), -critAnimHeight / 2, critAnimWidth, critAnimHeight)
        end
        gfx.ResetScissor()
    end

    do
        gfx.FillColor(255, 255, 255)
        
        gfx.DrawRect(critCap, -critWidth / 2 - critCapWidth / 2, -critCapHeight / 2, critCapWidth, critCapHeight)
        gfx.Scale(-1, 1) 
        
        gfx.DrawRect(critCap, -critWidth / 2 - critCapWidth / 2, -critCapHeight / 2, critCapWidth, critCapHeight)
        gfx.Scale(-1, 1) 
    end

    gfx.FillColor(255, 255, 255)
    gfx.ResetTransform()
end
                                     
render_crit_overlay = function(deltaTime)
    SetUpCritTransform()
    
    local xOffset = GetCritLineCenteringOffset()
    
    if portrait then
        gfx.Save()
        gfx.Translate(xOffset * 0, 0)

        local bfw, bfh = gfx.ImageSize(bottomFill)

        local distBetweenKnobs = 0.446
        local distCritVertical = 0.098

        local ioFillTx = bfw / 2
        local ioFillTy = bfh * distCritVertical 
        
        local io_x, io_y, io_w, io_h = -ioFillTx, -ioFillTy, bfw, bfh

        local consoleFillScale = (resx * 0.775) / (bfw * distBetweenKnobs)
        gfx.Scale(consoleFillScale, consoleFillScale);

        gfx.FillColor(255, 255, 255)
        gfx.DrawRect(bottomFill, io_x, io_y, io_w, io_h)
        
        for i = 1, 2 do
            SetFillToLaserColor(i)
            gfx.DrawRect(ioConsoleDetails[i], io_x, io_y, io_w, io_h)
        end
        
        gfx.GlobalCompositeOperation(gfx.BLEND_OP_LIGHTER)
        for i = 1, 6 do
            if game.GetButton(buttonsInOrder[i]) then
                consoleAnimTimers[i] = consoleAnimTimers[i] + deltaTime * consoleAnimSpeed * 3.14 * 2
            else 
                consoleAnimTimers[i] = 0
            end
            
            local timer = consoleAnimTimers[i]
            if timer ~= 0 then
                local image = consoleAnimImages[i]
                local alpha = (math.sin(timer) * 0.5 + 0.5) * 0.5 + 0.25
                gfx.FillColor(255, 255, 255, alpha * 255);
                gfx.DrawRect(image, io_x, io_y, io_w, io_h)
            end
        end
        gfx.GlobalCompositeOperation(gfx.BLEND_OP_SOURCE_OVER)

        gfx.Restore();
    end

    local cw, ch = gfx.ImageSize(laserCursor)
    local cursorWidth = 55 * scale
    local cursorHeight = cursorWidth * (ch / cw)
    
    for i = 1, 2 do
        local cursor = gameplay.critLine.cursors[i - 1]
        local pos, skew = cursor.pos, cursor.skew
        
        gfx.SkewX(skew)

        
        SetFillToLaserColor(i, cursor.alpha * 255)
        gfx.DrawRect(laserCursor, pos - cursorWidth / 2, -cursorHeight / 2, cursorWidth, cursorHeight)
        
        gfx.FillColor(255, 255, 255, cursor.alpha * 255)
        gfx.DrawRect(laserCursorOverlay, pos - cursorWidth / 2, -cursorHeight / 2, cursorWidth, cursorHeight)
        
        gfx.SkewX(-skew)
    end

    
    gfx.FillColor(255, 255, 255)
    gfx.ResetTransform()
end

function DrawBanner(deltaTime)
    local bannerWidth, bannerHeight = gfx.ImageSize(topFill)
    local actualHeight = desw * (bannerHeight / bannerWidth)

    gfx.FillColor(255, 255, 255)
    gfx.DrawRect(topFill, 0, 0, desw, actualHeight)

    return actualHeight
end

draw_stat = function(x,y,w,h, name, value, format,r,g,b)
  gfx.Save()
  gfx.Translate(x,y)
  gfx.TextAlign(gfx.TEXT_ALIGN_LEFT + gfx.TEXT_ALIGN_TOP)
  gfx.FontSize(h)
  gfx.Text(name .. ":",0, 0)
  gfx.TextAlign(gfx.TEXT_ALIGN_RIGHT + gfx.TEXT_ALIGN_TOP)
  gfx.Text(string.format(format, value),w, 0)
  gfx.BeginPath()
  gfx.MoveTo(0,h)
  gfx.LineTo(w,h)
  if r then gfx.StrokeColor(r,g,b) 
  else gfx.StrokeColor(200,200,200) end
  gfx.StrokeWidth(1)
  gfx.Stroke()
  gfx.Restore()
  return y + h + 5
end

drawSongInfo = function(deltaTime)
    if jacket == nil or jacket == jacketFallback then
        jacket = gfx.LoadImageJob(gameplay.jacketPath, jacketFallback)
    end
    gfx.Save()
    if portrait then gfx.Scale(0.7,0.7) end
    gfx.BeginPath()
    gfx.LoadSkinFont("bebaskai.ttf")
    gfx.Translate(5,5) --upper left margin
    gfx.FillColor(0,0,0,200);
    gfx.Rect(0,0,songInfoWidth+25,100)
    gfx.Fill()
    gfx.BeginPath()
    gfx.FillColor(255, 255, 255)
    gfx.ImageRect(0,0,jacketWidth,jacketWidth,jacket,1,0)
    --begin diff/level
    gfx.BeginPath()
    gfx.Rect(0,85,60,15)
    gfx.FillColor(0,0,0,200)
    gfx.Fill()
    gfx.BeginPath()
    gfx.FillColor(255,255,255)
    draw_stat(0,85,55,15,diffNames[gameplay.difficulty + 1], gameplay.level, "%02d")
    --end diff/level
    gfx.LoadSkinFont("Rounded_Elegance.ttf")
    gfx.TextAlign(gfx.TEXT_ALIGN_LEFT)
    gfx.FontSize(20)
    local textX2 = jacketWidth + 10
    local textX = 0
    titleWidth = songInfoWidth - jacketWidth - 20
    titleWidth2 = songInfoWidth
    gfx.Save()
    x1,y1,x2,y2 = gfx.TextBounds(0,0,gameplay.title)
    textscale = math.min(titleWidth / x2, 1)
    if portrait then
        textscale = textscale * 1.4
        gfx.Translate(desw/1.41, - 245)
    else
        gfx.Translate(desw/2, 0)
    end
    gfx.Scale(textscale, textscale)
    gfx.TextAlign(gfx.TEXT_ALIGN_TOP + gfx.TEXT_ALIGN_CENTER)
    gfx.Text(gameplay.title .. " / " .. gameplay.artist, 0, 0)
    gfx.Restore()
    x1,y1,x2,y2 = gfx.TextBounds(0,0,gameplay.artist)
    textscale = math.min(titleWidth / x2, 1)
    gfx.Save()
    gfx.Translate(textX, 60)
    gfx.Scale(textscale, textscale)
    gfx.LoadSkinFont("BEBASKAI.ttf")
    gfx.FontSize(36) 
    gfx.Restore()
    gfx.FillColor(255,255,255)
    gfx.FontSize(20) 
    gfx.LoadSkinFont("BEBASKAI.ttf")
    gfx.Text("YOUR POSITION", textX2 - 1, 25)
    gfx.FontSize(28) 
    gfx.Text(string.format("%.0f BPM", gameplay.bpm), textX2-2, 55)
    gfx.FontSize(16)
    gfx.Text(string.format("HiSpeed %.1f / %.0f", gameplay.hispeed, gameplay.bpm * gameplay.hispeed), textX2-2, 65)
    gfx.BeginPath()
    gfx.FillColor(0,150,255)
    gfx.StrokeColor(255,255,255,100)
    gfx.StrokeWidth(1)
    gfx.Rect(jacketWidth+10,25,(songInfoWidth - jacketWidth) * gameplay.progress,10)
    gfx.Fill()
    gfx.Stroke()
    gfx.BeginPath()
    gfx.FillColor(255,255,255,0)
    gfx.StrokeColor(255,255,255,100)
    gfx.StrokeWidth(1)
    gfx.Rect(jacketWidth+10,25,(songInfoWidth - jacketWidth),10)
    gfx.Fill()
    gfx.Stroke()
    if game.GetButton(game.BUTTON_STA) then
      gfx.BeginPath()
      gfx.FillColor(20,20,20,200);
      gfx.Rect(100,100, songInfoWidth - 100, 20)
      gfx.Fill()
      gfx.FillColor(255,255,255)
      gfx.Text(string.format("HiSpeed: %.0f x %.1f = %.0f", 
      gameplay.bpm, gameplay.hispeed, gameplay.bpm * gameplay.hispeed), 
      textX, 115)
    end
    gfx.Restore()
end

drawBestDiff = function(deltaTime,x,y)
    if not gameplay.scoreReplays[1] then return end
    if not showScoreReplay then return end
    gfx.BeginPath()
    gfx.FontSize(24)
    difference = score - gameplay.scoreReplays[1].currentScore
    local prefix = "+"
    gfx.FillColor(255,255,255)
    gfx.Text("BEST:", x - 64, y - 16)
    gfx.FontSize(36)
    if difference < 0 then 
        scorerank = false
        gfx.FillColor(255,50,50)
        difference = math.abs(difference)
        prefix = "-"
    elseif difference > 0 then
        scorerank = true
    end
    gfx.Text(string.format("%s%08d", prefix, difference), x - 6, y - 20)
end

drawScore = function(deltaTime)
    gfx.BeginPath()
    gfx.RoundedRectVarying(desw - 330,5,325,62,0,0,0,0)
    gfx.FillColor(0,0,0,200)
    gfx.Fill()
    gfx.LoadSkinFont("Rounded_Elegance.ttf")
    gfx.Translate(-5,5) -- upper right margin
    gfx.FillColor(255,255,255)
    gfx.TextAlign(gfx.TEXT_ALIGN_LEFT + gfx.TEXT_ALIGN_TOP)
    gfx.FontSize(54)
    gfx.Text(string.format("%08d", score),desw-225,0)
    gfx.FontSize(24)
    gfx.Text("SCORE:",desw-315,8)
    drawBestDiff(deltaTime, desw - 170, 66)
    gfx.Translate(5,-5) -- undo margin
end

drawGauge = function(deltaTime)
    local height = 1024 * scale * 0.35
    local width = 512 * scale * 0.35
    local posy = resy / 2 - height / 2
    local posx = resx - width * (1 - math.max(introTimer - 1, 0))
    if portrait then
        width = width * 0.8
        height = height * 0.8
        posy = posy - 30
        posx = resx - width * (1 - math.max(introTimer - 1, 0))
    end
    gfx.SetGaugeColor(0,100,200,255)
    gfx.SetGaugeColor(1,255,140,255)
    gfx.DrawGauge(gameplay.gauge, posx, posy, width, height, deltaTime)

    
    if doRenderGaugePercent then
        posx = posx / scale
        posx = posx + (100 * 0.35) 
        height = 880 * 0.35
        posy = posy / scale

        if portrait then
            height = height * 0.8;
            posx = posx - 10
        end
        posy = posy + (70 * 0.35) + height - height * gameplay.gauge

        gfx.BeginPath()
        gfx.RoundedRectVarying(posx-30, posy-16, 50, 23, 7,7,7,7)
        gfx.FillColor(0,0,0,200)
        gfx.Fill()

        gfx.FillColor(255,255,255)
        gfx.TextAlign(gfx.TEXT_ALIGN_RIGHT + gfx.TEXT_ALIGN_MIDDLE)
        gfx.FontSize(20)
        gfx.LoadSkinFont("Rounded_Elegance.ttf")
        gfx.Text(string.format("%d%%", math.floor(gameplay.gauge * 100)), posx + 16, posy - 3)
    end
end

drawCombo = function(deltaTime)
    if combo == 0 and game.GetButton(game.BUTTON_STA) == false then return end

    comboTimer = math.max(comboTimer - deltaTime,0)
    if comboTimer == 0 and game.GetButton(game.BUTTON_STA) == false then return nil end
    
    local randAlpha = 0
    local randPos = 0
    local alpha = 125
    if opaqueCombo then alpha = 255 end

    local posx = desw / 2
    local posy = desh * critLinePos[1] - 100
    if portrait then posy = desh * critLinePos[2] - 150 end
    gfx.BeginPath()
    gfx.TextAlign(gfx.TEXT_ALIGN_CENTER + gfx.TEXT_ALIGN_MIDDLE)

    comboString = tostring(combo)

    if gameplay.comboState == 2 then
        if uninterruptedCombo == "USC" then
            gfx.FillColor(130,255,30,alpha) --puc
        elseif uninterruptedCombo == "SDVX" then
            gfx.FillColor(255,200,40,alpha)
        elseif uninterruptedCombo == "none" then
            gfx.FillColor(255,255,255,alpha)
        end
    elseif gameplay.comboState == 1 then
        if uninterruptedCombo ~= "none" then
            gfx.FillColor(255,200,40,alpha) --uc
        else
            gfx.FillColor(255,255,255,alpha)
        end
    else
        gfx.FillColor(255,255,255,alpha) --regular
    end

    if staticCombo and not opaqueCombo then
        gfx.FontSize(16 * math.max(comboScale, 1))
        if staticCombo then gfx.FontSize(16) end
        if game.GetButton(game.BUTTON_STA) then gfx.FontSize(16) end
        gfx.LoadSkinFont("quantify.ttf")
        gfx.Text("-CHAIN-", posx + randPos, posy - 34)
    end

    gfx.LoadSkinFont("Quantify.ttf")

    if combo % 100 == 0 then
        comboScale = comboScale + deltaTime * 8
    else
        comboScale = comboScale - deltaTime * 3
    end

    gfx.FontSize(70 * math.max(comboScale, 1))
    if staticCombo and game.GetButton(game.BUTTON_STA) then
        if comboBurst then
            if combo % 100 == 0 then gfx.FontSize(70 * math.max(comboScale, 1)) end
        else
            gfx.FontSize(70)
        end
    end

    gfx.Text(comboString, posx + randPos, posy)
end

drawEarlate = function(deltaTime)
    local elpos
    if showEarlate == "high" then
        elpos = 400
    elseif showEarlate == "higher" then
        elpos = 500
    else
        elpos = 150
    end
    earlateTimer = math.max(earlateTimer - deltaTime,0)
    if earlateTimer == 0 and game.GetButton(game.BUTTON_STA) == false then return nil end
    local alpha = math.floor(earlateTimer * 20) % 2
    alpha = alpha * 100 + 55
    if earLateDisplay == "opaque" then
        alpha = 255
    elseif earLateDisplay == "high" then
        alpha = alpha * 50 + 55
        
    elseif earLateDisplay == "medium" then
        alpha = alpha * 160 + 55
    elseif earLateDisplay == "low" then
        alpha = alpha * 200 + 55
    end

    gfx.BeginPath()
    gfx.FontSize(35)
    gfx.LoadSkinFont("DS-DIGI.ttf")
    gfx.TextAlign(gfx.TEXT_ALIGN_CENTER, gfx.TEXT_ALIGN_MIDDLE)
    local ypos = desh * critLinePos[1] - elpos    
    if portrait then ypos = desh * critLinePos[2] - 50 - elpos end
    if showEarlate == "low" then ypos = ypos + 100 end
    if showEarlate ~= "hidden" then
        if late then
            gfx.FillColor(50,255,255, alpha)
            gfx.Text(">LATE<", desw / 2, ypos)
        else
            gfx.FillColor(255,50,255, alpha)
            gfx.Text(">EARLY<", desw / 2, ypos)
        end
    end
end

drawAlerts = function(deltaTime)
    gfx.FillColor(255, 255, 255)
    alertTimers[1] = math.max(alertTimers[1] - deltaTime,-2)
    alertTimers[2] = math.max(alertTimers[2] - deltaTime,-2)
    if alertTimers[1] > 0 then --draw left alert
        gfx.Save()
        local posx = desw / 2 - 350
        local posy = desh * critLinePos[1] - 135
        if portrait then 
            posy = desh * critLinePos[2] - 135 
            posx = 65
        end
        gfx.Translate(posx,posy)
        r,g,b = game.GetLaserColor(0)
        local alertScale = (-(alertTimers[1] ^ 2.0) + (1.5 * alertTimers[1])) * 5.0
        alertScale = math.min(alertScale, 1)
        gfx.Scale(1, alertScale)
        gfx.BeginPath()
        if useAlertSDVX then
            gfx.ImageRect(-50,-50,100,100,alertLeft,1,0)
        else
            gfx.RoundedRectVarying(-50,-50,100,100,0,20,0,20)
            gfx.StrokeColor(r,g,b)
            gfx.FillColor(20,20,20)
            gfx.StrokeWidth(2)
            gfx.Fill()
            gfx.Stroke()
            gfx.BeginPath()
            gfx.FillColor(r,g,b)
            gfx.TextAlign(gfx.TEXT_ALIGN_CENTER + gfx.TEXT_ALIGN_MIDDLE)
            gfx.FontSize(90)
            gfx.LoadSkinFont("bebaskai.ttf")
            gfx.Text("L",0,0)
            gfx.FontSize(20)
            gfx.FillColor(255,255,255)
            gfx.Text("ANALOG",0,-36)
            gfx.Text("DEVICE",0,38)
        end
        gfx.Restore()
    end
    if alertTimers[2] > 0 then --draw right alert
        gfx.Save()
        local posx = desw / 2 + 350
        local posy = desh * critLinePos[1] - 135
        if portrait then 
            posy = desh * critLinePos[2] - 135 
            posx = desw - 65
        end
        gfx.Translate(posx,posy)
        r,g,b = game.GetLaserColor(1)
        local alertScale = (-(alertTimers[2] ^ 2.0) + (1.5 * alertTimers[2])) * 5.0
        alertScale = math.min(alertScale, 1)
        gfx.Scale(1, alertScale)
        gfx.BeginPath()
        if useAlertSDVX then
            gfx.ImageRect(-50,-50,100,100,alertRight,1,0)
        else
            gfx.RoundedRectVarying(-50,-50,100,100,0,20,0,20)
            gfx.StrokeColor(r,g,b)
            gfx.FillColor(20,20,20)
            gfx.StrokeWidth(2)
            gfx.Fill()
            gfx.Stroke()
            gfx.BeginPath()
            gfx.FillColor(r,g,b)
            gfx.TextAlign(gfx.TEXT_ALIGN_CENTER + gfx.TEXT_ALIGN_MIDDLE)
            gfx.FontSize(90)
            gfx.LoadSkinFont("bebaskai.ttf")
            gfx.Text("R",0,0)
            gfx.FontSize(20)
            gfx.FillColor(255,255,255)
            gfx.Text("ANALOG",0,-36)
            gfx.Text("DEVICE",0,38)
        end
        gfx.Restore()
    end
end

render_intro = function(deltaTime)
    if not game.GetButton(game.BUTTON_STA) then
        introTimer = introTimer - deltaTime
    end
    introTimer = math.max(introTimer, 0)
    return introTimer <= 0
end

render_outro = function(deltaTime, clearState)
    if clearState == 0 then return true end
    gfx.ResetTransform()
    gfx.BeginPath()
    gfx.Rect(0,0,resx,resy)
    gfx.FillColor(0,0,0, math.floor(127 * math.min(outroTimer, 1)))
    gfx.Fill()
    gfx.Scale(scale,scale)
    gfx.TextAlign(gfx.TEXT_ALIGN_CENTER + gfx.TEXT_ALIGN_MIDDLE)
    gfx.FillColor(255,255,255, math.floor(255 * math.min(outroTimer, 1)))
    gfx.LoadSkinFont("Quantify.ttf")
    gfx.FontSize(70)
    gfx.Text(clearTexts[clearState], desw / 2, desh / 2)
    outroTimer = outroTimer + deltaTime
    return outroTimer > 2, 1 - outroTimer
end

update_score = function(newScore)
    score = newScore
end

update_combo = function(newCombo)
    combo = newCombo
    if burstCombo then
        if combo % 100 == 0 then
            comboScale = 1.4
        else
            if staticCombo then
                comboScale = 1
            else
                comboScale = 1.2
            end
        end
    else
        if staticCombo then
            comboScale = 1
        else
            comboScale = 1.2
        end
    end
    comboTimer = 0.75
end

near_hit = function(wasLate) 
    late = wasLate
    earlateTimer = 0.75
end

laser_alert = function(isRight) 
    if isRight and alertTimers[2] < -1.5 then alertTimers[2] = 1.5
    elseif alertTimers[1] < -1.5 then alertTimers[1] = 1.5
    end
end

gfx.ResetTransform()

-- ======================== Start mutliplayer ========================

json = require "json"

local normal_font = game.GetSkinSetting('multi.normal_font')
if normal_font == nil then
    normal_font = 'NotoSans-Regular.ttf'
end
local mono_font = game.GetSkinSetting('multi.mono_font')
if mono_font == nil then
    mono_font = 'NovaMono.ttf'
end

local users = nil

function init_tcp()
    Tcp.SetTopicHandler("game.scoreboard", function(data)
        users = {}
        for i, u in ipairs(data.users) do
            table.insert(users, u)
        end
    end)
end


-- Hook the render function and draw the scoreboard
local real_render = render
render = function(deltaTime)
    real_render(deltaTime)
    draw_users(deltaTime)
end

-- Update the users in the scoreboard
function score_callback(response)
    if response.status ~= 200 then 
        error() 
        return 
    end
    local jsondata = json.decode(response.text)
    users = {}
    for i, u in ipairs(jsondata.users) do
        table.insert(users, u)
    end
end

-- Render scoreboard
function draw_users(detaTime)
    if (users == nil) then
        return
    end

    local yshift = 0

    -- In portrait, we draw a banner across the top
    -- The rest of the UI needs to be drawn below that banner
    if portrait then
        local bannerWidth, bannerHeight = gfx.ImageSize(topFill)
        yshift = desw * (bannerHeight / bannerWidth)
        gfx.Scale(0.7, 0.7)
    end

    gfx.Save()

    -- Add a small margin at the edge
    gfx.Translate(5,yshift+200)

    -- Reset some text related stuff that was changed in draw_state
    gfx.TextAlign(gfx.TEXT_ALIGN_LEFT)
    gfx.FontSize(35)
    gfx.FillColor(255, 255, 255)
    local yoff = 0
    if portrait then
        yoff = 75;
    end
    local rank = 0
    for i, u in ipairs(users) do
        gfx.FillColor(255, 255, 255)
        local score_big = string.format("%04d",math.floor(u.score/1000));
        local score_small = string.format("%03d",u.score%1000);
        local user_text = '('..u.name..')';

        local size_big = 40;
        local size_small = 28;
        local size_name = 30;

        if u.id == gameplay.user_id then
            size_big = 48
            size_small = 32
            size_name = 40
            rank = i;
        end

        gfx.LoadSkinFont(mono_font)
        gfx.FontSize(size_big)
        gfx.Text(score_big, 0, yoff);
        local xmin,ymin,xmax,ymax_big = gfx.TextBounds(0, yoff, score_big);
        xmax = xmax + 7

        gfx.FontSize(size_small)
        gfx.Text(score_small, xmax, yoff);
        xmin,ymin,xmax,ymax = gfx.TextBounds(xmax, yoff, score_small);
        xmax = xmax + 7

        if u.id == gameplay.user_id then
            gfx.FillColor(237, 240, 144)
        end

        gfx.LoadSkinFont(normal_font)
        gfx.FontSize(size_name)
        gfx.Text(user_text, xmax, yoff)

        yoff = ymax_big + 15
    end

    gfx.Restore()
end