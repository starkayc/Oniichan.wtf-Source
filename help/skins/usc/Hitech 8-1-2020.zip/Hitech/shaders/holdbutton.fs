#extension GL_ARB_separate_shader_objects : enable

// Inputs
in vec2 fsTex;
in vec4 position;
flat in float noteLength;
flat in int type; // 0 = BT, 1 = FX

// Output
layout(location=0) out vec4 target;

uniform sampler2D mainTex;
uniform float objectGlow;
uniform float trackPos;
uniform float trackScale;
uniform float hiddenCutoff;
uniform float hiddenFadeWindow;
uniform float suddenCutoff;
uniform float suddenFadeWindow;

// 20Hz flickering. 0 = Miss, 1 = Inactive, 2 & 3 = Active alternating.
uniform int hitState;


float endShaper(float l)
{
    if (position.y * trackScale < l)
    {
        return position.y * trackScale / l;
    }

    if ((noteLength - position.y) * trackScale < l)
    {
        return (noteLength - position.y) * trackScale / l;
    }

    return 1.0;
}

void main()
{    
    // Note colours, feel free to change
    vec3 BTcolor = vec3(1.0, 0.95, 0.8);
    vec3 FxBaseColor = vec3(1.0, 0.25, 0.05);
    vec3 FxHighlightColor = vec3(1.0, 0.45, 0.05);

    float x = abs(fsTex.x - 0.5) * 2.0;

    if (type == 0)
    {
        const float endLength = 0.006;
        float squeeze = 1.0 - endShaper(endLength);

        x += squeeze * squeeze * squeeze;

        // Base
        float base = (1.0 - smoothstep(0.3, 0.35, x)) * 0.9;
        float glow = pow(max(1.0 - x, 0.0), 2.0) * 0.5;

        if (hitState > 1) // Hit
        {
            base *= 0.8;
        }
        else // Missed or inactive
        {
            // Darken center
            base = base * x * 1.8 + base * 0.3;
            // Dim glow
            glow *= 0.5;
        }

        float v = base + glow;

        target = vec4(BTcolor, v);
    }
    else
    {
        const float middleFadeLength = 0.04;
        const float sideFadeLength = 0.005;
        float midx = max(abs(1.0 - x), 0.0);
        float middle = pow(midx, 15);
        float base = pow(min(midx * 1.6, 1.0), 1.2) * 0.3;
        float side = pow(1.0 - min(abs(x - 0.6), 1.0), 40) * 1.2;

        float middleShape = endShaper(middleFadeLength);
        middle *= middleShape;
        base *= middleShape;
        side *= endShaper(sideFadeLength);

        float highlight = middle + side;

        target = vec4(FxHighlightColor * highlight + FxBaseColor * max(base, 1.0), min(base + highlight, 1.0));
    }

    target.xyz = target.xyz * (1.0 + objectGlow * 0.3);
    target.a = min(1.0, target.a + target.a * objectGlow * 0.9);
}
