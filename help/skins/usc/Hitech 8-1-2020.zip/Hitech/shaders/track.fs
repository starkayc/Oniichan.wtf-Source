#extension GL_ARB_separate_shader_objects : enable
layout(location=1) in vec2 fsTex;
layout(location=0) out vec4 target;

uniform sampler2D mainTex;
uniform vec4 lCol;
uniform vec4 rCol;
uniform float hidden;

float glow_peak(float pos, float samplePos)
{
    float spike = pow(max(1.0 - abs(pos - samplePos) * 4.0, 0.0), 70.0) * 1.5;
    float blur = pow(max(1.0 - abs(pos - samplePos) * 6.0, 0.0), 2.0) * 0.1;
    return min(spike + blur, 1.0);
}

void main()
{	
    const vec4 baseColor = vec4(0.5, 0.5, 0.59, 1.0);

    float x = fsTex.x;
    if (x < 1.0 / 12.0)
        target = glow_peak(0.05 / 6.0, x) * lCol * 1.2;
    else if (x < 3.0 / 12.0)
        target = glow_peak(1.0 / 6.0, x) * lCol * 1.2;
    else if (x < 5.0 / 12.0)
        target = glow_peak(2.0 / 6.0, x) * baseColor;
    else if (x < 7.0 / 12.0)
        target = glow_peak(3.0 / 6.0, x) * baseColor;
    else if (x < 9.0 / 12.0)
        target = glow_peak(4.0 / 6.0, x) * baseColor;
    else if (x < 11.0 / 12.0)
        target = glow_peak(5.0 / 6.0, x) * rCol * 1.2;
    else
        target = glow_peak(5.95 / 6.0, x) * rCol * 1.2;
    target.a = smoothstep(0.0, 0.025 / 6.0, x) * (1.0 - smoothstep(5.975 / 6.0, 1.0, x));

}
