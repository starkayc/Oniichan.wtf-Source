#extension GL_ARB_separate_shader_objects : enable

in vec2 fsTex;
in vec4 position;
flat in int type; // 0 = BT, 1 = FX
flat in int layer; // 0 = Base, 1 = Glow
flat in mat4 tpoints;

layout(location=0) out vec4 target;

uniform sampler2D mainTex;
uniform bool hasSample;

uniform float trackPos;
uniform float trackScale;
uniform float hiddenCutoff;
uniform float hiddenFadeWindow;
uniform float suddenCutoff;
uniform float suddenFadeWindow;


// This code contains many magic numbers that can tweak the look of things
// Please don't be too mad about all the unreadability


float dist2line(vec2 a, vec2 b, vec2 c)
{
    vec2 ab = b - a;
    vec2 ca = a - c;
    vec2 cb = b - c;
    float adot = dot(ca, ab);
    float bdot = dot(cb, ab);
    if (adot * bdot < 0)
    {
        float l = dot(ab, ab);
        return length(ca - adot * ab / l);
    }
    return min(length(ca), length(cb));
}


void main()
{
    vec4 mainColor;
    float glowExp, glowDamp;
    float sideRamp;
    if (type == 0) // BT
    {
        mainColor = vec4(1.0, 0.95, 0.8, 1.0); // Base colour
        glowExp = 20; // Glow fall-off curve exponent
        glowDamp = 17; // Glow fall-off multiplier
        sideRamp = 0.4;
    }
    else // FX
    {
        mainColor = vec4(1.0, 0.45, 0.05, 1.0); // Base colour
        glowExp = 15; // Glow fall-off curve exponent
        glowDamp = 20; // Glow fall-off multiplier
        sideRamp = 0.2;
    }

    if (layer == 0) // Base layer
    {
        float xdist = abs(fsTex.x - 0.5);
        float ydist = abs(fsTex.y - 0.5);
        mainColor.a = (1.0 - smoothstep(0.495, 0.505, ydist)) * max(1.0 - smoothstep(0.495, 0.505, xdist), (1.0 - xdist) * sideRamp);

        if(hasSample)
        {
            float addition = abs(0.5 - fsTex.x) * - 1.;
            addition += 0.2;
            addition = max(addition,0.);
            addition *= 2.8;
            mainColor.rgba += addition * max(mainColor.a, 0.1) * vec4(1.0, 0.7, 0.3, 1.0);
        }

        target = mainColor;
    }
    else // Screen space glow layer
    {
        // This horrid line calculates the minimum distance to the note border
        float dist = min(min(dist2line(tpoints[0].xy, tpoints[1].xy, position.xy), dist2line(tpoints[1].xy, tpoints[2].xy, position.xy)), min(dist2line(tpoints[2].xy, tpoints[3].xy, position.xy), dist2line(tpoints[3].xy, tpoints[0].xy, position.xy)));

        float glow = pow(max(1.0 - dist * glowDamp, 0.0), glowExp);
        target = vec4(mainColor.rgb * max(1.0, glow * 1.5), glow);

        if (hasSample) // Add a flare to notes with a sample
        {
            vec2 glowpos = fsTex - vec2(0.5);
            glowpos = pow(abs(glowpos * 3.0), vec2(0.25));
            target += vec4(mainColor.rgb * 0.7, (1.0 - glowpos.x) * (1.0 - glowpos.y) * 0.7);
        }
    }


    float off = trackPos + position.y * trackScale;

    if(hiddenCutoff < suddenCutoff)
    {
        float hiddenCutoffFade = hiddenCutoff - hiddenFadeWindow;
        if (off < hiddenCutoff) {
            target = target * max(0.0, (off - hiddenCutoffFade) / hiddenFadeWindow);
        }

        float suddenCutoffFade = suddenCutoff + suddenFadeWindow;
        if (off > suddenCutoff) {
            target = target * max(0.0, (suddenCutoffFade - off) / suddenFadeWindow);
        }
    }
    else
    {
        float hiddenCutoffFade = hiddenCutoff + hiddenFadeWindow;
        if (off > hiddenCutoff) {
            target = target * clamp((off - hiddenCutoffFade) / hiddenFadeWindow, 0.0, 1.0);
        }

        float suddenCutoffFade = suddenCutoff - suddenFadeWindow;
        if (off < suddenCutoff) {
            target = target * clamp((suddenCutoffFade - off) / suddenFadeWindow, 0.0, 1.0);
        }

        if (off > suddenCutoff && off < hiddenCutoff) {
            target = target * vec4(0.0);
        }
    }
}

