#extension GL_ARB_separate_shader_objects : enable
in vec2 fsTex;
in vec4 position;
flat in int layer;

layout(location=0) out vec4 target;

uniform sampler2D mainTex;
uniform vec4 color;
uniform float objectGlow;

uniform float trackPos;
uniform float trackScale;
uniform float hiddenCutoff;
uniform float hiddenFadeWindow;
uniform float suddenCutoff;
uniform float suddenFadeWindow;

// 20Hz flickering. 0 = Miss, 1 = Inactive, 2 & 3 = Active alternating.
uniform int hitState;

// 0 = body, 1 = entry, 2 = exit
uniform int laserPart;


void main()
{    
    float off = trackPos + position.y * trackScale;
    float x = fsTex.x;

    x = abs((x - 0.5) * 2.0);

    // Spike length scale. Higher value -> shorter spike
    const float spikemulti = 30.0;
    // Spike curve exponent. Changes spike shape
    const float spikeexp = 2.0;
    // Spike offset
    const float spikeoff = 1.0;

    x += pow(spikeoff - min(off * spikemulti, spikeoff), spikeexp);

    x = min(x - 1.0, 1.0);

    float base, glow;
    if (layer == 0)
    {   // Main laser
        base = smoothstep(-0.05, 0.05, -x) * 0.5;
        glow = pow(1.0 - abs(x), 10) * 3.3;
    }
    else if (layer == 1)
    {   // Laser glow
        base = sqrt(0.5 - x * 0.5) * 0.3;
        glow = smoothstep(0.0, 1.0, 1.0 - abs(x)) * 1.0;
    }
    else
    {   // Laser reflection
        base = smoothstep(-0.05, 0.05, -x) * 0.5;
        glow = pow(1.0 - abs(x), 10) * 3.3;
    }

    float v = base + glow;

    if (laserPart == 1) // Smooth entry
    {
        v *= (1.0 - fsTex.y);
    }
    else if (laserPart == 2) // Smooth exit
    {
        v *= fsTex.y;
    }

    target = v * color;

    
    float brightness = (target.r + target.g + target.b) / 3.0;
    target.xyz = target.xyz * (0.0 + objectGlow * 1.2);

    // Invert if missed
    target.xyz = min(target.rgb, 1.0);
    if (brightness > 0.7 && hitState == 0)
    {
        target.rgb = vec3(1.0) - target.rgb;
    }

    if (layer == 1)
    {
        target *= 0.3;
    }
    else if (layer == 2)
    {
        target *= 0.1;
    }
}
