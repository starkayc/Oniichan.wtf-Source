return {
	{
    name =  "Hoshikara's Room",
    password =  true,
    ingame =  true,
    max =  8,
    id =  "99b1eae1-09af-458a-8c4f-c59b49ffe08b",
    current = 5
	},
	{
    name = "Agent39's Room",
    password = false,
    ingame = false,
    max = 8,
    id = "99b1eae1-09af-458a-8c4f-c59b49dde08b",
    current = 3
  },
  {
    name =  "FroztySeven's Room",
    password =  true,
    ingame =  false,
    max =  8,
    id =  "99b1eae1-09af-458a-8c4f-c59b49ffe08b",
    current = 1
	},
	{
    name = "AZER's Room",
    password = true,
    ingame = true,
    max = 8,
    id = "99b1eae1-09af-458a-8c4f-c59b49dde08b",
    current = 8
  },
  {
    name =  "Phoenix's Room",
    password =  false,
    ingame =  true,
    max =  8,
    id =  "99b1eae1-09af-458a-8c4f-c59b49ffe08b",
    current = 2
	},
	{
    name = "altoids's Room",
    password = false,
    ingame = true,
    max = 8,
    id = "99b1eae1-09af-458a-8c4f-c59b49dde08b",
    current = 4
  },
  {
    name =  "zzxxzzyy's Room",
    password =  true,
    ingame =  true,
    max =  8,
    id =  "99b1eae1-09af-458a-8c4f-c59b49ffe08b",
    current = 2
	}
};
