return {
  mirror_mode = false,
  owner = '3537c10d-ad91-494d-84bf-a0d1113c2529',
  join_token = '1ad63f2737a81e5a2834cc053ace0591',
  hard_mode = false,
  diff = 1,
  audio_hash = '6268f79d89ff4cd8da40c9eb4d08548e7ea22dba',
  hash = '6268f79d89ff4cd8da40c9eb4d08548e7ea22dba',
  users = {
    {
      missing_map =  false,
      id =  '3537c10d-ad91-494d-84bf-a0d1113c2529',
      score =  9884994,
      combo =  547,
      clear =  2,
      level =  10,
      name =  Hoshikara,
      ready =  true
    }
  },
  replay_id = 1,
  host = '3537c10d-ad91-494d-84bf-a0d1113c2529',
  start_soon = false,
  chart_hash = '6268f79d89ff4cd8da40c9eb4d08548e7ea22dba',
  topic = room.update,
  song = tribal_trial,
  level = 10,
  replay_name = '',
  do_rotate =  false
};