return {
  {
    score = 9358764,
    name = 'Hoshikara',
    id = 'b6938f2a-d8da-4c0c-a6d0-5bd3a8627384'
  },
  {
    score = 9248597,
    name = 'notHoshikara',
    id = 'b6933f2a-d8da-4c0c-a6d0-5bd3a8627384'
  },
};
