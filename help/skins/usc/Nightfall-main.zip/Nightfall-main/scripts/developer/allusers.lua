return {
  {
    missing_map = false,
    id = '3537c10d-ad91-494d-84bf-a0d1113c2529',
    score = 10000000,
    combo = 2193,
    clear = 5,
    level = 18,
    name = 'Hoshikara',
    ready = true
  },
  {
    missing_map = false,
    id = '3537c10d-ad91-494d-84bf-a0d1123c2529',
    score = 9913874,
    combo = 1592,
    clear = 2,
    level = 15,
    name = 'zzxxzzyy',
    ready = false
  },
  {
    missing_map = false,
    id = '3537c10d-ad91-494d-84bf-a0d1133c2529',
    score = 9884994,
    combo = 1018,
    clear = 4,
    level = 18,
    name = '39daph',
    ready = false
  },
  {
    missing_map = true,
    id = '3537c10d-ad91-494d-84bf-a0d1143c2529',
    score = 9821095,
    combo = 777,
    clear = 2,
    level = 15,
    name = 'sneaky',
    ready = false
  },
  {
    missing_map = false,
    id = '3537c10d-ad91-494d-84bf-a0d1153c2529',
    score = 9564297,
    combo = 689,
    clear = 3,
    level = 12,
    name = 'casino',
    ready = true
  },
  {
    missing_map = false,
    id = '3537c10d-ad91-494d-84bf-a0d1163c2529',
    score = 9513598,
    combo = 407,
    clear = 2,
    level = 12,
    name = 'ddx',
    ready = true
  },
  {
    missing_map = true,
    id = '3537c10d-ad91-494d-84bf-a0d1173c2529',
    score = 9498976,
    combo = 404,
    clear = 2,
    level = 15,
    name = 'psyqui',
    ready = false
  },
  {
    missing_map = true,
    id = '3537c10d-ad91-494d-84bf-a0d1183c2529',
    score = 9388916,
    combo = 281,
    clear = 1,
    level = 18,
    name = 'mini',
    ready = false
  }
};
