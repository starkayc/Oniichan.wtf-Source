---@type string[]
local Difficulties = {
  'NOVICE',
  'ADVANCED',
  'EXHAUST',
  'MAXIMUM',
  'INFINITE',
  'GRAVITY',
  'HEAVENLY',
  'VIVID',
};

return Difficulties;