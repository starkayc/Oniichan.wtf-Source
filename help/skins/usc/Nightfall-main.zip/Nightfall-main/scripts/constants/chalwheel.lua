return {
  bpm = 'BPM',
  challenge = 'CHALLENGE',
  clear = 'CLEAR',
  pct = 'COMPLETION',
  diff = 'DIFFICULTY',
  grade = 'GRADE',
  reqs = 'REQUIREMENTS',
  title = 'TITLE',
};