-- sortwheel `sorts` table

---@type string[] # Array of song sorts
sorts = {};