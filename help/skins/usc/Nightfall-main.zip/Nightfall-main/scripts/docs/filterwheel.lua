-- filterwheel `filters` table

---@class filters
---@field folder string[] # Array of song folders and collections
---@field level string[] # Array of song levels
filters = {};