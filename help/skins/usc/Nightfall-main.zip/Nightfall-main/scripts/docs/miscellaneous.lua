-- Miscellaneous information

---@alias deltaTime number # Difference (delta) in time since the last frame, evaluates to `1 / current FPS`