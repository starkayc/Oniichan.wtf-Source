render_bg = function(dt)
end
