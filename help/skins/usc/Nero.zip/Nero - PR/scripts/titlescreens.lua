local mposx = 0;
local mposy = 0;
local hovered = nil;
local cursorIndex = 1
local buttonWidth = 250;
local buttonHeight = 70;
local buttonBorder = 2;
local label = -1;
local gr_r, gr_g, gr_b, gr_a = game.GetSkinSetting("Menu_stroke_color")
gfx.GradientColors(0,127,255,255,0,128,255,0)
local gradient = gfx.LinearGradient(0,0,0,0)
local bgAngle = 0.5
local bgPatternTimer = 0
local cursorYs = {}
local buttons = nil
local resx, resy = game.GetResolution();
local versionString = "USC-2020081800 0.4"
local skinVersion = "(rel-0.3.1)"

local playerName = game.GetSkinSetting('nick')
local greetingText = game.GetSkinSetting('Greeting_text')
local authorText = game.GetSkinSetting('show_author')
local greetingColor = game.GetSkinSetting('Greeting_color')
local logoColor = game.GetSkinSetting('Logo_color')
local menuColor = game.GetSkinSetting('Menu_color')
local menuStroke = game.GetSkinSetting('Menu_stroke_color')

local backgroundImage = gfx.CreateSkinImage("title/bg.jpg", 1);
local railings = gfx.CreateSkinImage("title/railings.png", 1);
local clouds_1 = gfx.CreateSkinImage("title/clouds-1.png", 1);
local clouds_2 = gfx.CreateSkinImage("title/clouds-2.png", 1);
local ground = gfx.CreateSkinImage("title/ground.png", 1);
local planet = gfx.CreateSkinImage("title/planet.png", 1);
local sky = gfx.CreateSkinImage("title/sky.png", 1);
local lea = gfx.CreateSkinImage("title/lea.png", 1);
local played = false

game.LoadSkinSample("muSadtheme")

if played == false then 
	game.PlaySample("muSadtheme")
end


view_update = function()
    if package.config:sub(1,1) == '\\' then --windows
        updateUrl, updateVersion = game.UpdateAvailable()
        os.execute("start " .. updateUrl)
    else --unix
        --TODO: Mac solution
        os.execute("xdg-open " .. updateUrl)
    end
end

mouse_clipped = function(x,y,w,h)
    return mposx > x and mposy > y and mposx < x+w and mposy < y+h;
end;

draw_button = function(button, x, y)
	local name = button[1]
    local rx = x - (buttonWidth / 8);
    local ty = y - (buttonHeight - 68);
    gfx.BeginPath();
    gfx.TextAlign(gfx.TEXT_ALIGN_LEFT + gfx.TEXT_ALIGN_TOP);
	
	gfx.FontSize(40);
	gfx.LoadSkinFont("PixelHallfeticaJP12P-Bold.ttf");
	
	if mouse_clipped(rx,ty, buttonWidth, buttonHeight) then
       hovered = button[2];
	   b_r, b_g, b_b, b_a = game.GetSkinSetting("Menu_stroke_color")
	   gfx.FillColor(game.GetSkinSetting("Menu_stroke_color"));
	   gfx.Text(name, x+1, y+1);
	   gfx.Text(name, x-1, y+1);
	   gfx.Text(name, x+1, y-1);
	   gfx.Text(name, x-1, y-1);
    end
	gfx.FillColor(game.GetSkinSetting("Menu_color"));
    gfx.Text(name, x, y);
	return buttonHeight - 2;
end;


function setButtons()
	if buttons == nil then
		buttons = {}
		buttons[1] = {"START", Menu.Start}
		buttons[2] = {"MULTIPLAYER", Menu.Multiplayer}
		buttons[3] = {"GET SONGS", Menu.DLScreen}
		buttons[4] = {"SETTINGS", Menu.Settings}
		buttons[5] = {"EXIT GAME", Menu.Exit}
		
	end
end

function sign(x)
  return x>0 and 1 or x<0 and -1 or 0
end


function roundToZero(x)
	if x<0 then return math.ceil(x)
	elseif x>0 then return math.floor(x)
	else return 0 end
end

function deltaKnob(delta)
	if math.abs(delta) > 1.5 * math.pi then 
		return delta + 2 * math.pi * sign(delta) * -1
	end
	return delta
end



local lastKnobs = nil
local knobProgress = 0
function handle_controller()
	if game.GetButton(game.BUTTON_STA) then
		buttons[cursorIndex][2]()
	end

	if lastKnobs == nil then
		lastKnobs = {game.GetKnob(0), game.GetKnob(1)}
	else
		local newKnobs = {game.GetKnob(0), game.GetKnob(1)}
	
		knobProgress = knobProgress - deltaKnob(lastKnobs[1] - newKnobs[1]) * 1.2
		knobProgress = knobProgress - deltaKnob(lastKnobs[2] - newKnobs[2]) * 1.2
		
		lastKnobs = newKnobs
		
		if math.abs(knobProgress) > 1 then
			cursorIndex = (((cursorIndex - 2) + roundToZero(knobProgress)) % #buttons) + 2
			knobProgress = knobProgress - roundToZero(knobProgress)
		end
	end
end

render = function(deltaTime)
	setButtons()
    resx,resy = game.GetResolution();
	mposx,mposy = game.GetMousePos();
	gfx.BeginPath()
	gfx.ImageRect(0, 0, resx, resy, backgroundImage, 1, 0);
	gfx.BeginPath()
    gfx.Rect(30,340,260,2)
    gfx.FillColor(255,255,255)
	gfx.Fill()
	
	cursorGet = 1
    buttonY = 360;
    hovered = nil;
	
    gfx.LoadSkinFont("PixelHallfeticaJP12P-Bold.ttf");
	
	for i=1,#buttons do
		cursorYs[i] = buttonY
		buttonY = buttonY + draw_button(buttons[i], 30, buttonY);
		if hovered == buttons[i][2] then
			cursorIndex = i
		end
	end
	
	handle_controller()
		
    gfx.BeginPath();
	gfx.FontSize(100);
	if label == -1 then
		gfx.LoadSkinFont("Polo-SemiScriptEx.ttf");
		label = gfx.CreateLabel("NERO", 95, 0);
		label1 = gfx.CreateLabel("NERO", 95, 0);

	end
	gfx.TextAlign(gfx.TEXT_ALIGN_LEFT + gfx.TEXT_ALIGN_TOP);
	gfx.FillColor(0,0,0, 200);
	gfx.DrawLabel(label, 10, resy -935, resx-40);
	gfx.FillColor(255,255,255);
	gfx.DrawLabel(label1, 10, resy -940, resx-40);
	gfx.TextAlign(gfx.TEXT_ALIGN_LEFT + gfx.TEXT_ALIGN_BOTTOM);
	gfx.FontSize(30)
	gfx.LoadSkinFont("PixelHallfeticaJP12P-Bold.ttf");
	gfx.BeginPath();
	gfx.FillColor(0,0,0, 200);
	gfx.Text(string.format("%s %s!", greetingText, playerName), 30, 337);
	gfx.FillColor(255,255,255);
	gfx.Text(string.format("%s %s!", greetingText, playerName), 30, 335);
	gfx.BeginPath();
	gfx.FillColor(255,255,255);
	gfx.Rect(100,100,20,20);
	gfx.FontSize(25)
	if authorText then
	gfx.FillColor(0,0,0, 200);
	gfx.Text("by StarKayC", 250, 267);
	gfx.FillColor(255,255,255);
	gfx.Text("by StarKayC", 250, 265);
	end

	gfx.TextAlign(gfx.TEXT_ALIGN_RIGHT + gfx.TEXT_ALIGN_BOTTOM);
	gfx.FontSize(30)
	gfx.FillColor(0,0,0, 200);
	gfx.Text("Nero (rel-0.4)", resx - 5, resy - 3);
	gfx.FillColor(255,255,255);
	gfx.Text("Nero (rel-0.4)", resx - 5, resy - 5);


	gfx.BeginPath();
	gfx.TextAlign(gfx.TEXT_ALIGN_LEFT + gfx.TEXT_ALIGN_TOP);
	gfx.FontSize(30)
	gfx.FillColor(0,0,0, 200);
	gfx.Text(versionString, 15, 10);
	gfx.FillColor(255,255,255);
	gfx.Text(versionString, 15, 7);
	

    if updateUrl then
       gfx.BeginPath()
       gfx.TextAlign(gfx.TEXT_ALIGN_BOTTOM + gfx.TEXT_ALIGN_LEFT)
       gfx.FontSize(30)
       gfx.Text(string.format("Version %s is now available", updateVersion), 5, resy - buttonHeight - 10)
       draw_button({"View", view_update}, buttonWidth / 2 + 5, resy - buttonHeight / 2 - 5);
       draw_button({"Update", Menu.Update}, buttonWidth * 1.5 + 15, resy - buttonHeight / 2 - 5)
    end
end;

mouse_pressed = function(button)
    if hovered then
        hovered()
        game.StopSample("muSadtheme")
    end
    return 0
end

function button_pressed(button)
    if button == game.BUTTON_STA then 
        buttons[cursorIndex][2]()
        game.StopSample("muSadtheme")
    elseif button == game.BUTTON_BCK then
        Menu.Exit()
    end
end