local jacket = nil
local resx,resy = game.GetResolution()
local scale = math.min(resx / 800, resy /800)
local gradeImg;
local diffNamesImg;
local gradear = 1 --grade aspect ratio
local desw = 800
local desh = 800
local moveX = 0
local moveY = 0
if resx / resy > 1 then
    moveX = resx / (2*scale) - 400
else
    moveY = resy / (2*scale) - 400
end
local diffNames = {"NOV", "ADV", "EXH", "INF"}
--local gradeNames = {"A", "AA", "AAA", "B", "C", "D", "S"}

local backgroundImage = gfx.CreateSkinImage("bg.png", 1);
game.LoadSkinSample("applause")
local played = false
local shotTimer = 0;
local shotPath = "";
game.LoadSkinSample("shutter")


get_capture_rect = function()
    local x = moveX -310
    local y = moveY * scale
    local w = resx 
    local h = resy
    return x,y,w,h
end

screenshot_captured = function(path)
    shotTimer = 10;
    shotPath = path;
    game.PlaySample("shutter")
end

draw_shotnotif = function(x,y)
    gfx.Save()
    gfx.Translate(x,y)
    gfx.TextAlign(gfx.TEXT_ALIGN_LEFT + gfx.TEXT_ALIGN_TOP)
    gfx.BeginPath()
    gfx.Rect(400,0,200,40)
    gfx.FillColor(0,128,255,60)
    gfx.StrokeColor(0,128,255)
    gfx.Fill()
    gfx.Stroke()
    gfx.FillColor(255,255,255)
    gfx.FontSize(15)
    gfx.Text("Screenshot saved to:", 405,5)
    gfx.Text(shotPath, 405,20)
    gfx.Restore()
end

draw_stat = function(x,y,w,h, name, value, format,r,g,b)
    gfx.Save()
    gfx.Translate(x,y)
    gfx.TextAlign(gfx.TEXT_ALIGN_LEFT + gfx.TEXT_ALIGN_TOP)
    gfx.FontSize(h)
    gfx.Text(name .. ":",0, 0)
    gfx.TextAlign(gfx.TEXT_ALIGN_RIGHT + gfx.TEXT_ALIGN_TOP)
    gfx.Text(string.format(format, value),w, 0)
    gfx.BeginPath()
    gfx.MoveTo(0,h)
    gfx.LineTo(w,h)
    if r then gfx.StrokeColor(r,g,b) 
    else gfx.StrokeColor(200,200,200) end
    gfx.StrokeWidth(1)
    gfx.Stroke()
    gfx.Restore()
    return y + h + 5
end

draw_line = function(x1,y1,x2,y2,w,r,g,b)
    gfx.BeginPath()
    gfx.MoveTo(x1,y1)
    gfx.LineTo(x2,y2)
    gfx.StrokeColor(r,g,b)
    gfx.StrokeWidth(w)
    gfx.Stroke()
end

draw_highscores = function()
    gfx.TextAlign(gfx.TEXT_ALIGN_LEFT)
    gfx.LoadSkinFont("PixelHallfeticaJP10P-Regular.ttf")
    gfx.FontSize(32)
    gfx.Text("Highscores:",840,45)
    for i,s in ipairs(result.highScores) do
        gfx.TextAlign(gfx.TEXT_ALIGN_LEFT)
        gfx.BeginPath()
        local ypos =  60 + (i - 1) * 80
        gfx.RoundedRectVarying(840,ypos, 280, 70,0,0,0,0)
        gfx.FillColor(15,15,15,60)
        gfx.StrokeColor(0,128,255)
        gfx.StrokeWidth(2)
        gfx.Fill()
        gfx.Stroke()
        gfx.BeginPath()
        gfx.FillColor(255,255,255)
        gfx.FontSize(23)
        gfx.LoadSkinFont("joystix.ttf")
        gfx.Text(string.format("#%d",i), 845, ypos + 20)
        gfx.FontSize(40)
        gfx.TextAlign(gfx.TEXT_ALIGN_CENTER + gfx.TEXT_ALIGN_TOP)
        gfx.Text(string.format("%08d", s.score), 985, ypos + 10)
        gfx.LoadSkinFont("PixelHallfeticaJP10P-Regular.ttf")
        gfx.FontSize(20)
        if s.timestamp > 0 then
            gfx.Text(os.date("%m-%d-%Y %H:%M", s.timestamp), 980, ypos + 47)
        end
    end
end

draw_graph = function(x,y,w,h)
    gfx.BeginPath()
    gfx.Rect(x,y,w,h)
    gfx.FillColor(0,0,0,10)
    gfx.Fill()    
    gfx.BeginPath()
    gfx.MoveTo(x,y + h - h * result.gaugeSamples[1])
    for i = 2, #result.gaugeSamples do
        gfx.LineTo(x + i * w / #result.gaugeSamples,y + h - h * result.gaugeSamples[i])
    end
	if result.flags & 1 ~= 0 then
		gfx.StrokeWidth(2.0)
		gfx.StrokeColor(255,80,0)
		gfx.Stroke()
	else
		gfx.StrokeWidth(2.0)
		gfx.StrokeColor(0,180,255)
		gfx.Scissor(x, y + h * 0.3, w, h * 0.7)
		gfx.Stroke()
		gfx.ResetScissor()
		gfx.Scissor(x,y,w,h*0.3)
		gfx.StrokeColor(255,0,255)
		gfx.Stroke()
		gfx.ResetScissor()
	end
end

render = function(deltaTime, showStats)
	gfx.BeginPath()
    gfx.ImageRect(0, 0, resx, resy, backgroundImage, 0.3, 0);
    gfx.Scale(scale,scale)
    gfx.Translate(moveX,moveY)
    if result.badge > 1 and not played then
        game.PlaySample("applause")
        played = true
    end
    if jacket == nil then
        jacket = gfx.CreateImage(result.jacketPath, 0)
    end
    if not gradeImg then
        gradeImg = gfx.CreateSkinImage(string.format("score/%s.png", result.grade),0)
        local gradew,gradeh = gfx.ImageSize(gradeImg)
        gradear = gradew/gradeh
    end

    if not diffNamesImg then 

        diffNamesImg = gfx.CreateSkinImage(string.format("result/%s.png", diffNames[result.difficulty + 1]),0)
        local dfw = 258
        local dfh = 277
    end
    --Title and jacket
    gfx.LoadSkinFont("PixelHallfeticaJP12P-Bold.ttf")
    gfx.BeginPath()
    gfx.FillColor(255,255,255)
    gfx.TextAlign(gfx.TEXT_ALIGN_CENTER)
    gfx.FontSize(50)
    gfx.Text(result.title, 400, 70)
    gfx.FontSize(30)
    gfx.Text(result.artist, 400, 110)
    if jacket then
        gfx.ImageRect(250,150,300,300,jacket,1,0)
    end
    gfx.BeginPath()
    --Jacket
    --gfx.Rect(250,430,60,20)
   -- gfx.FillColor(0,0,0,200)
   --  gfx.Fill()
   -- gfx.BeginPath()
    --gfx.FillColor(255,255,255)
   -- draw_stat(250,430,55,20,diffNames[result.difficulty + 1], result.level, "%02d")
    gfx.BeginPath()
    gfx.LoadSkinFont("joystix.ttf")
    gfx.Rect(-265,369,300,92)
    gfx.FillColor(0,128,255,60)
    gfx.StrokeColor(0,128,255)
    gfx.StrokeWidth(2)
    gfx.Fill()
    gfx.Stroke()
    draw_graph(-265,370,300,90)
    gfx.BeginPath()
    gfx.ImageRect(350,455,60 * gradear,60,gradeImg,1,0)
    
    --Difficulty Badge
    gfx.BeginPath()
    gfx.ImageRect(505 ,120, 258 / 3, 277 / 3, diffNamesImg, 1, 0)
    gfx.FontSize(40)
    gfx.Text(string.format("%02d", result.level), 547,170)
    
    --Gauge Number
    gfx.BeginPath()
    gfx.FontSize(15)
    gfx.TextAlign(gfx.TEXT_ALIGN_LEFT + gfx.TEXT_ALIGN_MIDDLE)
    gfx.Text(string.format("%d%%", math.floor(result.gauge * 100)), -5,452)
	if result.autoplay then
	    gfx.FontSize(20)
		gfx.TextAlign(gfx.TEXT_ALIGN_CENTER + gfx.TEXT_ALIGN_MIDDLE)
		--gfx.Text("Autoplay", 400, 135)
	end
	
    --Score data
    gfx.BeginPath()
    gfx.Rect(150,520,500,120)
    gfx.FillColor(0,128,255,60)
    gfx.StrokeColor(255,0,82)
    gfx.StrokeWidth(2)
    gfx.Fill()
    gfx.Stroke()
    gfx.BeginPath()
    gfx.FillColor(255,255,255)
    gfx.FontSize(85)
    gfx.TextAlign(gfx.TEXT_ALIGN_CENTER)
    gfx.Text(string.format("%08d", result.score), 400 -2, 605)
    gfx.BeginPath()
    gfx.RoundedRectVarying(151,521, 70, 22,0,0,20,0)
    gfx.FillColor(255,0,82)
    gfx.Fill()
    gfx.BeginPath()
    gfx.FillColor(255,255,255)
    gfx.LoadSkinFont("Polo-SemiScriptEx.ttf")
    gfx.FontSize(13)
    gfx.Text("SCORE", 184, 537);
    gfx.Fill()

     -- Critical Line
     gfx.BeginPath()
     gfx.LoadSkinFont("PixelHallfeticaJP10P-Regular.ttf")
     gfx.RoundedRect(-280,500,30,30,1)
     gfx.Rect(-280,529,161,3)
     gfx.FillColor(255, 237, 0)
     gfx.Fill()
     gfx.BeginPath()
     gfx.MoveTo(-120,530)
     gfx.LineTo(-90,500)
     gfx.StrokeColor(255,237,0)
     gfx.StrokeWidth(3)
     gfx.Stroke()
     gfx.BeginPath()
     gfx.Rect(-92,499,145,3)
     gfx.FillColor(255, 237, 0)
     gfx.Fill()

      -- Near Line
      gfx.BeginPath()
      gfx.RoundedRect(-280,550,30,30,1)
      gfx.Rect(-280,579,161,3)
      gfx.FillColor(37,255,160)
      gfx.Fill()
      gfx.BeginPath()
      gfx.MoveTo(-120,581)
      gfx.LineTo(-90,551)
      gfx.StrokeColor(37,255,160)
      gfx.StrokeWidth(3)
      gfx.Stroke()
      gfx.BeginPath()
      gfx.Rect(-92,550,145,3)
      gfx.FillColor(37,255,160)
      gfx.Fill()

      -- Error Line
      gfx.BeginPath()
      gfx.RoundedRect(-280,600,30,30,1)
      gfx.Rect(-280,629,161,3)
      gfx.FillColor(255,0,82)
      gfx.Fill()
      gfx.BeginPath()
      gfx.MoveTo(-120,631)
      gfx.LineTo(-90,601)
      gfx.StrokeColor(255,0,82)
      gfx.StrokeWidth(3)
      gfx.Stroke()
      gfx.BeginPath()
      gfx.Rect(-92,600,145,3)
      gfx.FillColor(255,0,82)
      gfx.Fill()

      -- Early Line
      gfx.BeginPath()
      gfx.RoundedRect(-280,650,30,30,1)
      gfx.Rect(-280,679,161,3)
      gfx.FillColor(255,0,132)
      gfx.Fill()
      gfx.BeginPath()
      gfx.MoveTo(-120,681)
      gfx.LineTo(-90,651)
      gfx.StrokeColor(255,0,132)
      gfx.StrokeWidth(3)
      gfx.Stroke()
      gfx.BeginPath()
      gfx.Rect(-92,650,145,3)
      gfx.FillColor(255,0,132)
      gfx.Fill()

       -- Late Line
       gfx.BeginPath()
       gfx.RoundedRect(-280,700,30,30,1)
       gfx.Rect(-280,729,161,3)
       gfx.FillColor(37,255,160)
       gfx.Fill()
       gfx.BeginPath()
       gfx.MoveTo(-120,730)
       gfx.LineTo(-90,700)
       gfx.StrokeColor(37,255,160)
       gfx.StrokeWidth(3)
       gfx.Stroke()
       gfx.BeginPath()
       gfx.Rect(-92,699,145,3)
       gfx.FillColor(37,255,160)
       gfx.Fill()

       -- Max Combo Line
       gfx.BeginPath()
       gfx.RoundedRect(-280,750,30,30,1)
       gfx.Rect(-280,779,161,3)
       gfx.FillColor(255,255,255)
       gfx.Fill()
       gfx.BeginPath()
       gfx.MoveTo(-120,781)
       gfx.LineTo(-90,751)
       gfx.StrokeColor(255,255,255)
       gfx.StrokeWidth(3)
       gfx.Stroke()
       gfx.BeginPath()
       gfx.Rect(-92,750,145,3)
       gfx.FillColor(255,255,255)
       gfx.Fill()
    
    --Left Column
    gfx.TextAlign(gfx.TEXT_ALIGN_LEFT)
    gfx.FontSize(24)
    gfx.FillColor(255,255,255)
    gfx.Text("CRITICAL", -248, 528);
    gfx.Text("NEAR", -248, 578);
    gfx.Text("ERROR",-248, 627);
    gfx.Text("EARLY",-248, 677);
    gfx.Text("LATE",-248, 727);
    gfx.Text("MAX COMBO",-248, 777);

    --Right Column
    gfx.TextAlign(gfx.TEXT_ALIGN_RIGHT)
    gfx.LoadSkinFont("joystix.ttf")
    gfx.FontSize(30)
    gfx.Text(string.format("%d", result.perfects), 0, 530);
    gfx.Text(string.format("%d", result.goods), 0, 580);
    gfx.Text(string.format("%d", result.misses), 0, 629);
    gfx.Text(string.format("%d", result.earlies), 0, 679);
    gfx.Text(string.format("%d", result.lates), 0, 729);
    gfx.Text(string.format("%d", result.maxCombo), 0, 779);

    --Delta Column
    gfx.BeginPath()
    gfx.Rect(275,650,250,90)
    gfx.FillColor(0,128,255,60)
    gfx.StrokeColor(255,0,82)
    gfx.StrokeWidth(2)
    gfx.Fill()
    gfx.Stroke()
    gfx.BeginPath()
    gfx.FillColor(255,255,255)
    gfx.TextAlign(gfx.TEXT_ALIGN_LEFT)
    gfx.FontSize(20)
    gfx.LoadSkinFont("PixelHallfeticaJP10P-Regular.ttf")
    gfx.Text("MEDIAN DELTA:", 285, 680);
    gfx.Text("MEAN DELTA:", 285, 720);
    gfx.TextAlign(gfx.TEXT_ALIGN_RIGHT)
    gfx.LoadSkinFont("joystix.ttf")
    gfx.FontSize(18)
    gfx.Text(string.format("%dms", result.medianHitDelta), 505, 680);
    gfx.Text(string.format("%.1fms", result.meanHitDelta), 505, 720);
    gfx.Fill()

    draw_highscores()
    
    gfx.LoadSkinFont("NotoSans-Regular.ttf")
    shotTimer = math.max(shotTimer - deltaTime, 0)
    if shotTimer > 1 then
        draw_shotnotif(505,755);
    end
end