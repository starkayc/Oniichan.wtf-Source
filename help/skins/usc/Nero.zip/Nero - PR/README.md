# Nero 
Nero is a personal skin made by StarKayC.

# Credits:

* **LucidWave (Hoshikara)** - difficulties textures, console textures, BT/FX button textures/shaders, backgrounds, lasers textures/shaders, hit animations, appeal cards, and song select.
* **Lasergame (fdigl)** - track textures, gauges textures, and gameplay score.
* **SiMPLiSTiX (fdigl)** - Score textures, badges textures, and song select loading texture.
* **NSC (Local Atticus)** - border texture, and background.
