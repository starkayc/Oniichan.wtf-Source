local transitionTimer = 0
local outTimer = 1
local animTimer = 0
local scale
local played = false
game.LoadSkinSample("select_song2")
game.LoadSkinSample("result")
local shutter = {
gfx.CreateSkinImage("transition/top.png", 0),
gfx.CreateSkinImage("transition/middle.png", 0),
gfx.CreateSkinImage("transition/side.png", 0),
gfx.CreateSkinImage("transition/bottom.png", 0),
gfx.CreateSkinImage("transition/bg2.png", 0),
gfx.CreateSkinImage("transition/logo.png", 0)
}
local console = gfx.CreateSkinImage("console/console.png", 0)

local resx, resy -- The resolution of the window
local portrait -- whether the window is in portrait orientation
local desw, desh -- The resolution of the design
local scale -- the scale to get from design to actual units
function ResetLayoutInformation()
    resx, resy = game.GetResolution()
    portrait = resy > resx
    desw = portrait and 720 or 1280 
    desh = desw * (resy / resx)
    scale = resx / desw
end

function gfx.DrawRect(kind, x, y, w, h)
    local doFill = kind == RECT_FILL or kind == RECT_FILL_STROKE
    local doStroke = kind == RECT_STROKE or kind == RECT_FILL_STROKE

    local doImage = not (doFill or doStroke)

    gfx.BeginPath()

    if doImage then
        gfx.ImageRect(x, y, w, h, kind, math.min(2-outTimer,1), 0)
    else
        gfx.Rect(x, y, w, h)
        if doFill then gfx.Fill() end
        if doStroke then gfx.Stroke() end
    end
end

function render(deltaTime)
    render_bars(transitionTimer)
    transitionTimer = transitionTimer + deltaTime
    transitionTimer = math.min(transitionTimer,1)
    return transitionTimer >= 1
end

function render_out(deltaTime)
    outTimer = outTimer + deltaTime
    outTimer = math.min(outTimer, 2)
    render_bars(outTimer)
    return outTimer >= 2;
end

function sign(x)
  return x>0 and 1 or x<0 and -1 or 0
end

function render_bars(progress)
    ResetLayoutInformation()
    if not played then
    game.PlaySample("select_song2")
	played = true
	end
	
	animTimer = transitionTimer * 2 - outTimer
	
    gfx.Save()
    gfx.BeginPath()
	gfx.ImageRect(0,0, resx, resy, shutter[5],animTimer, 0)
	if portrait then
	gfx.Save()
	gfx.Translate(resx/2, resy/2)
	gfx.BeginPath()
	gfx.ImageRect(-365 * scale,(540-animTimer*400)* scale,730* scale,400* scale,shutter[4],animTimer,0)
	gfx.Restore()
	gfx.Save()
	gfx.Translate(0, resy/2)
	gfx.BeginPath()
	gfx.ImageRect((-120+animTimer*120)* scale,-450* scale,120* scale,700* scale,shutter[3],animTimer,0)
	gfx.Restore()
	gfx.Save()
	gfx.Translate(resx, resy/2)
	gfx.BeginPath()
	gfx.ImageRect((120-animTimer*120)* scale,-450* scale,-120* scale,700* scale,shutter[3],animTimer,0)
	gfx.Restore()
    gfx.Translate(resx/2, resy/2)
	local bfw, bfh = gfx.ImageSize(console)

        local distBetweenKnobs = 0.446
        local distCritVertical = 0.098

        local ioFillTx = bfw / 2
        local ioFillTy = bfh * distCritVertical -- 0.098

        -- The total dimensions for the console image
        local io_x, io_y, io_w, io_h = -ioFillTx, -ioFillTy, bfw, bfh

        -- Adjust the transform accordingly first
        local consoleFillScale = (resx * 0.555) / (bfw * distBetweenKnobs)
        gfx.Scale(consoleFillScale, consoleFillScale);

        -- Actually draw the fill
        gfx.FillColor(255, 255, 255)
        gfx.DrawRect(console, io_x, -io_y * 4.72  / math.min(2-outTimer,1), io_w, io_h)
    gfx.Restore()
	end
    gfx.Translate(resx/2, resy/2)
	gfx.BeginPath()
	gfx.ImageRect(-375 * scale,(-1000+animTimer*360)* scale,750* scale,300* scale,shutter[1],animTimer,0)
	gfx.BeginPath()
	gfx.ImageRect(-325 * scale,(portrait and -432 or -325) * scale,650* scale,650* scale, shutter[2],animTimer, 0)
	gfx.BeginPath()
	gfx.ImageRect(-101 * scale,(portrait and -201 or - 101) * scale,202* scale,188* scale, shutter[6],animTimer, 0)
end