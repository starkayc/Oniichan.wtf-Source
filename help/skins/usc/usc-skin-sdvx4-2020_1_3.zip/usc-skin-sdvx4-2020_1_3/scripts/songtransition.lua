local transitionTimer = 0
local outTimer = 1
local animTimer = 0
local animTimer2 = 0
local jacket = 0
local scale
local played = false
game.LoadSkinSample("select_song")
local shutter = {
gfx.CreateSkinImage("transition/top.png", 0),
gfx.CreateSkinImage("transition/middle.png", 0),
gfx.CreateSkinImage("transition/side.png", 0),
gfx.CreateSkinImage("transition/bottom.png", 0),
gfx.CreateSkinImage("transition/bg1.png", 0),
gfx.CreateSkinImage("transition/jacketbg.png", 0),
gfx.CreateSkinImage("transition/extrack.png", 0),
}
local console = gfx.CreateSkinImage("console/console.png", 0)

local resx, resy -- The resolution of the window
local portrait -- whether the window is in portrait orientation
local desw, desh -- The resolution of the design
local scale -- the scale to get from design to actual units
function ResetLayoutInformation()
    resx, resy = game.GetResolution()
    portrait = resy > resx
    desw = portrait and 720 or 1280 
    desh = desw * (resy / resx)
    scale = resx / desw
end

function gfx.DrawRect(kind, x, y, w, h)
    local doFill = kind == RECT_FILL or kind == RECT_FILL_STROKE
    local doStroke = kind == RECT_STROKE or kind == RECT_FILL_STROKE

    local doImage = not (doFill or doStroke)

    gfx.BeginPath()

    if doImage then
        gfx.ImageRect(x, y, w, h, kind, 1, 0)
    else
        gfx.Rect(x, y, w, h)
        if doFill then gfx.Fill() end
        if doStroke then gfx.Stroke() end
    end
end

local largeFont = ImageFont.new("font-large", "0123456789")
local diffImages = {
    gfx.CreateSkinImage("song_select/level/novice.png", 0),
    gfx.CreateSkinImage("song_select/level/advanced.png", 0),
    gfx.CreateSkinImage("song_select/level/exhaust.png", 0),
    gfx.CreateSkinImage("song_select/level/gravity.png", 0)
}

function render(deltaTime)
    render_screen(transitionTimer)
    transitionTimer = transitionTimer + deltaTime
    transitionTimer = math.min(transitionTimer,1)
    if song.jacket == 0 and jacket == 0 then
        jacket = gfx.CreateSkinImage("song_select/jacket_loading.png", 0)
    elseif jacket == 0 then
        jacket = song.jacket
    end
    return transitionTimer >= 1
end

function render_out(deltaTime)
    outTimer = outTimer + deltaTime * 2
    outTimer = math.min(outTimer, 2)
    render_screen(outTimer)
    return outTimer >= 2;
end

function sign(x)
  return x>0 and 1 or x<0 and -1 or 0
end

function render_screen(progress)
    ResetLayoutInformation()
    if not played then
    game.PlaySample("select_song")
	played = true
	end
	
	animTimer = transitionTimer * 2 - outTimer

    gfx.Save()
    gfx.BeginPath()
	gfx.ImageRect(0,0, resx, resy, shutter[5],animTimer, 0)
	if portrait then
	gfx.Save()
	gfx.Translate(resx/2, resy/2)
	gfx.BeginPath()
	gfx.ImageRect(-365 * scale,(540-animTimer*400)* scale,730* scale,400* scale,shutter[4],animTimer,0)
	gfx.Restore()
	gfx.Save()
	gfx.Translate(0, resy/2)
	gfx.BeginPath()
	gfx.ImageRect((-120+animTimer*120)* scale,-450* scale,120* scale,700* scale,shutter[3],animTimer,0)
	gfx.Restore()
	gfx.Save()
	gfx.Translate(resx, resy/2)
	gfx.BeginPath()
	gfx.ImageRect((120-animTimer*120)* scale,-450* scale,-120* scale,700* scale,shutter[3],animTimer,0)
	gfx.Restore()
	end
    gfx.Translate(resx/2, resy/2)
	gfx.BeginPath()
	gfx.ImageRect(-375 * scale,(-1000+animTimer*360)* scale,750* scale,300* scale,shutter[1],animTimer,0)
	gfx.BeginPath()
	gfx.ImageRect(-325 * scale,(portrait and -432 or -375) * scale,650* scale,650* scale, shutter[2],animTimer, 0)--
	gfx.BeginPath()
	gfx.ImageRect((portrait and -290 or -250) * scale,((portrait and -375 or - 310)-animTimer*50)* scale,(portrait and 580 or 500)* scale,(portrait and 580 or 500)* scale,shutter[6],animTimer,0)
	gfx.BeginPath()
	gfx.ImageRect((portrait and -215 or -185) * scale,((portrait and -250 or -202)-animTimer*56)* scale,(portrait and 430 or 370)* scale,(portrait and 430 or 370)* scale,jacket,animTimer,0)
	gfx.BeginPath()
	gfx.ImageRect(-230 * scale, 150* scale,453* scale ,150* scale,shutter[7],animTimer,0)
	local bfw, bfh = gfx.ImageSize(console)

        local distBetweenKnobs = 0.446
        local distCritVertical = 0.098

        local ioFillTx = bfw / 2
        local ioFillTy = bfh * distCritVertical -- 0.098

        -- The total dimensions for the console image
        local io_x, io_y, io_w, io_h = -ioFillTx, -ioFillTy, bfw, bfh

        -- Adjust the transform accordingly first
        local consoleFillScale = (resx * 0.555) / (bfw * distBetweenKnobs)
        gfx.Scale(consoleFillScale, consoleFillScale);

        -- Actually draw the fill
        gfx.FillColor(255, 255, 255)
        gfx.DrawRect(console, io_x, -io_y * 4.72 / (transitionTimer) , io_w, io_h)
    gfx.Restore()
	gfx.Translate(resx/2, resy/2)
		-- Draw diff
    gfx.BeginPath()
	gfx.Scale(scale,scale)
    gfx.ImageRect(135 , 174, 92, 84 , diffImages[song.difficulty + 1], animTimer, 0)
	local levelText = string.format("%02d", song.level)
    largeFont:draw(levelText,175, 215, animTimer, gfx.TEXT_ALIGN_CENTER, gfx.TEXT_ALIGN_MIDDLE)
	
	if math.floor(animTimer) == 1 then
	gfx.LoadSkinFont("rounded-mplus-1c-bold.ttf")
	gfx.FillColor(55, 55, 55,64)
    gfx.TextAlign(gfx.TEXT_ALIGN_CENTER + gfx.TEXT_ALIGN_MIDDLE)
	local title = gfx.CreateLabel(song.title, 21, 0)
	gfx.DrawLabel(title,-28, 205, 300)
	local artist = gfx.CreateLabel(song.artist, 16, 0)
	gfx.DrawLabel(artist,-28, 232, 300)
	gfx.FillColor(55, 55, 55,225)
	local effector = gfx.CreateLabel(song.effector, 16, 0)
	gfx.DrawLabel(effector,8, 255, 230)
	local illustrator = gfx.CreateLabel(song.illustrator, 16, 0)
	gfx.DrawLabel(illustrator,8, 279, 230)
	gfx.DrawLabel(title,-30, 203, 300)
	gfx.DrawLabel(artist,-30, 230, 300)
	gfx.LoadSkinFont("airone.ttf")
	gfx.FillColor(88, 209, 248,255)
	gfx.TextAlign(gfx.TEXT_ALIGN_LEFT + gfx.TEXT_ALIGN_TOP)
	gfx.FontSize(20)
    gfx.Text(song.bpm,-95,165)
	end
end