local jacket = nil
local resx,resy = game.GetResolution()
local gradeImg;
local gradear = 1 --grade aspect ratio
local moveX = 0
local moveY = 0
  local desw = 720
  local desh = 1280
  local scale = resy / desh
  local xshift = (resx - desw * scale) / 2
  local yshift = (resy - desh * scale) / 2
if resx / resy > 1 then
    moveX = resx / (2*scale) - 400
else
    moveY = resy / (2*scale) - 400
end
local played = false
local shotTimer = 0;
local shotPath = "";
game.LoadSkinSample("result")
game.LoadSkinSample("shutter")

get_capture_rect = function()
    local x = xshift
    local y = yshift
    local w = desw*scale
    local h = desh*scale
    return x,y,w,h
end

screenshot_captured = function(path)
    shotTimer = 10;
    shotPath = path;
    game.PlaySample("shutter")
end

draw_shotnotif = function(x,y)
    gfx.Save()
    gfx.Translate(x,y)
    gfx.TextAlign(gfx.TEXT_ALIGN_LEFT + gfx.TEXT_ALIGN_TOP)
    gfx.BeginPath()
    gfx.Rect(0,0,200,40)
    gfx.FillColor(30,30,30)
    gfx.StrokeColor(255,128,0)
    gfx.Fill()
    gfx.Stroke()
    gfx.FillColor(255,255,255)
    gfx.FontSize(15)
    gfx.Text("Screenshot saved to:", 3,5)
    gfx.Text(shotPath, 3,20)
    gfx.Restore()
end

draw_stat = function(x,y,w,h, name, value, format,r,g,b)
    gfx.Save()
    gfx.Translate(x,y)
    gfx.TextAlign(gfx.TEXT_ALIGN_LEFT + gfx.TEXT_ALIGN_TOP)
    gfx.FontSize(h)
    gfx.Text(name .. ":",0, 0)
    gfx.TextAlign(gfx.TEXT_ALIGN_RIGHT + gfx.TEXT_ALIGN_TOP)
    gfx.Text(string.format(format, value),w, 0)
    gfx.BeginPath()
    gfx.MoveTo(0,h)
    gfx.LineTo(w,h)
    if r then gfx.StrokeColor(r,g,b) 
    else gfx.StrokeColor(200,200,200) end
    gfx.StrokeWidth(1)
    gfx.Stroke()
    gfx.Restore()
    return y + h + 5
end

draw_line = function(x1,y1,x2,y2,w,r,g,b)
    gfx.BeginPath()
    gfx.MoveTo(x1,y1)
    gfx.LineTo(x2,y2)
    gfx.StrokeColor(r,g,b)
    gfx.StrokeWidth(w)
    gfx.Stroke()
end

draw_graph = function(x,y,w,h)
    gfx.BeginPath()
    gfx.Rect(x,y,w,h)
    gfx.FillColor(0,0,0,210)
    gfx.Fill()    
    gfx.BeginPath()
    gfx.MoveTo(x,y + h - h * result.gaugeSamples[1])
    for i = 2, #result.gaugeSamples do
        gfx.LineTo(x + i * w / #result.gaugeSamples,y + h - h * result.gaugeSamples[i])
    end
    gfx.StrokeWidth(2.0)
    gfx.StrokeColor(0,180,255)
    gfx.Stroke()
end

function gfx.DrawRect(kind, x, y, w, h)
    local doFill = kind == RECT_FILL or kind == RECT_FILL_STROKE
    local doStroke = kind == RECT_STROKE or kind == RECT_FILL_STROKE

    local doImage = not (doFill or doStroke)

    gfx.BeginPath()

    if doImage then
        gfx.ImageRect(x, y, w, h, kind, 1, 0)
    else
        gfx.Rect(x, y, w, h)
        if doFill then gfx.Fill() end
        if doStroke then gfx.Stroke() end
    end
end

function load_number_image(path)
    local images = {}
    for i = 0, 9 do
        images[i + 1] = gfx.CreateSkinImage(string.format("%s/%d.png", path, i), 0)
    end
    return images
end

local gaugescoreImages = load_number_image("score_gauge")

function draw_number(x, y, alpha, num, digits, images, is_dim,scale)
    local tw, th = gfx.ImageSize(images[1])
	tw = tw*scale
	th = th*scale
    x = x + (tw * (digits - 1)) / 2
    y = y - th / 2
    for i = 1, digits do
        local mul = 10 ^ (i - 1)
        local digit = math.floor(num / mul) % 10
        local a = alpha
        if is_dim and num < mul then
            a = 0
        end
        gfx.BeginPath()
        gfx.ImageRect(x, y, tw, th, images[digit + 1], a, 0)
        x = x - tw
    end
end
	
local nickName = game.GetSkinSetting("nick")
local statusBack = Image.skin("result/status_result.png")
local apealCard = gfx.CreateSkinImage(string.format("appeal_card/%d.png", game.GetSkinSetting("appealcard")), 0)
local trophy = Image.skin("trophy.png")
local status = Image.skin("result/status.png")
local crewEmblem = gfx.CreateSkinImage(string.format("crew/icons/%d.png", game.GetSkinSetting("crew")),0)
local ypos = 450
function draw_status()
    -- Draw the background
    gfx.FillColor(255, 255, 255)
    statusBack:draw({ x = 0, y = desh / 2 - 70 + ypos, anchor_h = Image.ANCHOR_LEFT })
	
	-- Draw the status
    gfx.FillColor(255, 255, 255)
    status:draw({ x = 0, y = desh / 2 - 150 + ypos, anchor_h = Image.ANCHOR_LEFT })

    -- Draw the apeal card
	gfx.DrawRect(apealCard,25, desh / 2 - 130 + ypos, 102 * 0.75, 129 * 0.75)
    --apealCard:draw({ x = 25, y = desh / 2 - 130 + ypos, w = apealCard.w * 0.75, h = apealCard.h * 0.75, anchor_h = Image.ANCHOR_LEFT, anchor_v = Image.ANCHOR_TOP })

    -- Draw the trophy
    trophy:draw({ x = 145, y = desh / 2 - 65 + ypos, w = trophy.w * 0.5, h = trophy.h * 0.5 })
	
	-- Draw the crew emblem
    gfx.DrawRect(crewEmblem,25, desh / 2 - 50 + ypos, 40, 40)
	
	 -- Draw the nickname
	gfx.TextAlign(gfx.TEXT_ALIGN_LEFT + gfx.TEXT_ALIGN_MIDDLE)
    gfx.LoadSkinFont("nickname.ttf")
    gfx.FontSize(25)
	gfx.FillColor(255, 255, 255)
    gfx.Text(nickName,115,desh / 2 - 107 + ypos)
	
end


local info = gfx.CreateSkinImage("info.png", 0)
function draw_info(deltaTime)
-- Draw the background
	gfx.FillColor(255, 255, 255)
	gfx.ImageRect(scale*370, scale*360, 827 * scale / 1.8, 1459 * scale / 1.8,info, 1 , 0)
end


local largeFont = ImageFont.new("font-large", "0123456789")
local diffImages = {
    gfx.CreateSkinImage("song_select/level/novice.png", 0),
    gfx.CreateSkinImage("song_select/level/advanced.png", 0),
    gfx.CreateSkinImage("song_select/level/exhaust.png", 0),
    gfx.CreateSkinImage("song_select/level/gravity.png", 0)
}
local results = {
gfx.CreateSkinImage("result/crash.png", 0),
gfx.CreateSkinImage("result/comp.png", 0),
gfx.CreateSkinImage("result/uc.png", 0),
gfx.CreateSkinImage("result/per.png", 0)
}
local scoreNumber = load_number_image("score_result")

local res = 0
function draw_result()

gfx.BeginPath()
if math.floor(result.gauge*100) < 70 then
if result.flags == 1 then
if math.floor(result.gauge*100) == 0 then
res = 1
else
res = 2
end
else
res = 1
end
elseif math.floor(result.gauge*100) >= 70 then
res = 2
end
if result.misses == 0 then
res = 3
elseif result.goods == 0 and result.misses == 0 then
res = 4
end
tw, th = gfx.ImageSize(results[res])
gfx.ImageRect(500, 403, tw / 3.4, th / 3.4 , results[res], 1 , 0)

end

local testimg = gfx.CreateSkinImage("transition/bg2.png",0)
local gaugeimg = {
gfx.CreateSkinImage("result/gaugeframe.png",0),
gfx.CreateSkinImage("result/gauge1.png",0),
gfx.CreateSkinImage("result/gauge2.png",0),
gfx.CreateSkinImage("result/gauge3.png",0)
}
function draw_gauge(deltaTime)
  gfx.BeginPath()
  gfx.ImageRect(385,642,300,-50,gaugeimg[1],1,0)
  
  gfx.Scissor(387, 580 , math.floor(result.gauge * 100) * 3 * 0.97, 70)
  --gfx.BeginPath()
  --gfx.ImageRect(0,0,720,1280,testimg,0.5,0)
  
  local gaugetype = 2
  if result.flags == 1 then
  gaugetype = 4
  elseif math.floor(result.gauge * 100) >= 70 then
  gaugetype = 3
  else
  gaugetype = 2
  end
  
  gfx.BeginPath()
  gfx.ImageRect(385,642,300,-50,gaugeimg[gaugetype],1,0)
  
  gfx.ResetScissor()
  
  gfx.BeginPath()
  gfx.LoadSkinFont("RussellSquare.ttf")
  gfx.FontSize(14)
  gfx.TextAlign(gfx.TEXT_ALIGN_RIGHT + gfx.TEXT_ALIGN_MIDDLE)
  gfx.FillColor(50, 50, 50)
  gfx.Text(string.format("%d%%", math.floor(result.gauge * 100)),674,642)
  gfx.FillColor(255, 255, 255)
  gfx.Text(string.format("%d%%", math.floor(result.gauge * 100)),672,640)
end

local crew = gfx.CreateSkinImage(string.format("crew/%d/crew.png", game.GetSkinSetting("crew")), 0)
local creweyes = {
gfx.CreateSkinImage("crew/1/eye1.png",0),
gfx.CreateSkinImage("crew/1/eye2.png",0),
gfx.CreateSkinImage("crew/1/eye3.png",0)
}
local eyetimer = 0
local crewpos = 0
local alpha = 0
local alphatimer = 0

function draw_crew(deltaTime)
    tw, th = gfx.ImageSize(crew)	
	
	--Draw the crew 0
	if game.GetSkinSetting("crew") == 0 then
	gfx.BeginPath()
    gfx.ImageRect(-110,310,tw*1.1,th*1.1,crew,1,0)
	
	--Draw the crew 1
	elseif game.GetSkinSetting("crew") == 1 then
    crewpos = crewpos + deltaTime
	local crewX = -255
	local crewY = 300 + math.cos(crewpos)*10
	
    gfx.BeginPath()
	gfx.ImageRect(crewX,crewY,tw,th,crew,1,-0.2)
	gfx.BeginPath()
	gfx.ImageRect(crewX,crewY,tw,th,creweyes[1],1,-0.2)

	eyetimer = eyetimer + deltaTime
	
	if eyetimer > 10 then
	eyetimer = 0
	end
	if math.floor(eyetimer*10) == 80 or  math.floor(eyetimer*10) == 84 then
	gfx.BeginPath()
	gfx.ImageRect(crewX,crewY,tw,th,creweyes[1],1,-0.2)
	elseif math.floor(eyetimer*10) == 81 or math.floor(eyetimer*10) == 83 then
	gfx.BeginPath()
	gfx.ImageRect(crewX,crewY,tw,th,creweyes[2],1,-0.2)
	elseif math.floor(eyetimer*10) == 82 then
	gfx.BeginPath()
	gfx.ImageRect(crewX,crewY,tw,th,creweyes[3],1,-0.2)
	end
	
	--Draw the crew 2
	elseif game.GetSkinSetting("crew") == 2 then
	gfx.BeginPath()
    gfx.ImageRect(-160,306,tw*1.05,th*1.05,crew,1,0)
	else
	
	end
end


  dataBg = Image.skin("result/bg.png")
  filltop = Image.skin("fill_top.png")
  filltop1 = Image.skin("fill_top1.png")
  fillGlow = Image.skin("fill_topglow.png")
  filltext1 = Image.skin("fill_text.png")
  FillText = gfx.CreateSkinImage("fill_text.png", 0)
  info = Image.skin("result/info.png")
  local gradeAlpha = 1.0
  local bannerTimer = 0.0
  local textTimer = 0.0
  
  
render = function(deltaTime, showStats)
  gfx.Translate(xshift, yshift)
  gfx.Scale(scale, scale)
  
    if jacket == nil then
        jacket = gfx.CreateImage(result.jacketPath, 0)
    end
	if not gradeImg then
        gradeImg = gfx.CreateSkinImage(string.format("score/%s.png", result.grade),0)
    end
	
  gfx.Scissor(0, 0, 720, 1280)
	
  --Draw the background
  dataBg:draw({ x = 0, y = 0,w = 720, h = 1280, anchor_h = Image.ANCHOR_LEFT, anchor_v = Image.ANCHOR_TOP})
  
    
  --Draw the crew
	draw_crew(deltaTime)
	
  --Draw the info
  info:draw({ x = 720, y = 350, w = 400, h = 800, anchor_h = Image.ANCHOR_RIGHT, anchor_v = Image.ANCHOR_TOP })
  
  alphatimer  = alphatimer + deltaTime
  alpha = math.floor(alphatimer * 20) % 2
  alpha = (alpha * 30 + 225) / 255
  gfx.BeginPath()
  gfx.ImageRect(380,357,112,122,gradeImg,alpha,0)
  
  draw_number(470, 515, 1.0, math.floor(result.score/1000), 5, scoreNumber, false,1.3)
  draw_number(643, 521, 1.0, result.score, 3, scoreNumber, false,0.9)
  
  gfx.LoadSkinFont("NovaMono.ttf")
  gfx.FillColor(255,255,255)
	for i,s in ipairs(result.highScores) do
	if i == 1 then
	gfx.FontSize(26)
	gfx.Text(string.format("%08d",s.score),620, 561)
	gfx.FontSize(33)
	gfx.Text(string.format("%08d",result.score - s.score),600, 582)
	end
	end
	
  draw_result()
  
    gfx.TextAlign(gfx.TEXT_ALIGN_CENTER + gfx.TEXT_ALIGN_MIDDLE)
    gfx.FontSize(28)
    gfx.Text(string.format("%d", result.perfects),595, 678);
    gfx.Text(string.format("%d", result.goods),595, 704);
	gfx.Text(string.format("%d", result.earlies),497, 728);
	gfx.Text(string.format("%d", result.lates),590, 728);
    gfx.Text(string.format("%d", result.misses),595, 754);
	gfx.Text(string.format("%d", result.maxCombo),595, 786);
	gfx.TextAlign(gfx.TEXT_ALIGN_LEFT + gfx.TEXT_ALIGN_MIDDLE)
	gfx.FontSize(23)
	gfx.FillColor(0,0,0)
	gfx.Text("MEDIAN DELTA",400, 920);
	gfx.Text("MEAN DELTA",400, 950);
	gfx.FillColor(52,143,191)
	gfx.Text(string.format("%dms", result.medianHitDelta),600, 920);
	gfx.Text(string.format("%.1fms", result.meanHitDelta),600, 950);
	
  --Draw the gauge
    draw_gauge(deltaTime)
  
	
	
  --Draw the status
	draw_status()
  
  --Draw the top frame
  filltop1:draw({ x = 0, y = 20, w = 720, h = 400, anchor_h = Image.ANCHOR_LEFT, anchor_v = Image.ANCHOR_TOP })
  
  filltop:draw({ x = 0, y = 0, w = 720, h = 400, anchor_h = Image.ANCHOR_LEFT, anchor_v = Image.ANCHOR_TOP })
  
    bannerTimer = bannerTimer + deltaTime
	textTimer = textTimer + deltaTime
	textoffset = (textTimer * 50) % 570
	
	if bannerTimer > 1.8 then
	bannerTimer = bannerTimer - 1.8
	end
  
  gfx.Scissor(0, 170 - bannerTimer * 120, 720, 60)
  fillGlow:draw({ x = 0, y = 0, w = 720, h = 400, anchor_h = Image.ANCHOR_LEFT, anchor_v = Image.ANCHOR_TOP })
  gfx.ResetScissor()
  
  gfx.Scissor(65, 90, 590, 20)

  filltext1:draw({ x = textoffset - 570, y = 96, w = 570, h = 7, anchor_h = Image.ANCHOR_LEFT, anchor_v = Image.ANCHOR_TOP })
  filltext1:draw({ x = textoffset, y = 96, w = 570, h = 7, anchor_h = Image.ANCHOR_LEFT, anchor_v = Image.ANCHOR_TOP })
  filltext1:draw({ x = textoffset + 570, y = 96, w = 570, h = 7, anchor_h = Image.ANCHOR_LEFT, anchor_v = Image.ANCHOR_TOP })
	
  gfx.ResetScissor()
  
  
  
  
	
  --Draw the Title and jacket
    gfx.BeginPath()
    tw, th = gfx.ImageSize(diffImages[result.difficulty + 1])
    gfx.ImageRect(555, 210, tw, th , diffImages[result.difficulty + 1], 1, 0)
	local levelText = string.format("%02d", result.level)
    largeFont:draw(levelText,  600 , 250, 1, gfx.TEXT_ALIGN_CENTER, gfx.TEXT_ALIGN_MIDDLE)

	if jacket then
	    gfx.BeginPath()
        gfx.ImageRect(82,215,80,80,jacket,1,0)
    end
	
    gfx.LoadSkinFont("rounded-mplus-1c-bold.ttf")

    gfx.TextAlign(gfx.TEXT_ALIGN_CENTER + gfx.TEXT_ALIGN_MIDDLE)
    local title = gfx.CreateLabel(result.title, 22, 0)
    gfx.FontSize(20)
	gfx.FillColor(20,20,20)
	gfx.DrawLabel(title,362, 267, 300)
	gfx.FillColor(255,255,255)
	gfx.DrawLabel(title,360, 265, 300)

	
	local artist = gfx.CreateLabel(result.artist, 19, 0)
	gfx.FillColor(20,20,20)
	gfx.DrawLabel(artist,362, 297, 300)
	gfx.FillColor(255,255,255)
	gfx.DrawLabel(artist,360, 295, 300)
	
	--Draw the screenshots
    gfx.LoadSkinFont("segoeui.ttf")
    shotTimer = math.max(shotTimer - deltaTime, 0)
    if shotTimer > 1 then
    draw_shotnotif(505,755);
    end
	
	
	gfx.ResetScissor()
end