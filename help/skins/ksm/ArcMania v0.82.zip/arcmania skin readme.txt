ArcMania (Arcaea skin for K-ShootMania) version 0.82 - First Release

Help that I got:

-From wQYakisobaQw - He tried his best to help for the Arc Flare but I found a better way to rip it. Thanks for the help anyway.

-Plist live viewer - I used this to render the hold animation that arcaea has provided from their game that only have a single ".png" image and an animation script. Took me forever searching how to do it. (http://www.effecthub.com/particle2dx)




Next release:

Version 1.00
-Complete modification of the entire skin
-Removing some of the elements that are not needed for clean-up purposes.
-Backgrounds from Arcaea (resized for the skin)


Soon:
-Additional where Infinity difficulty name can be swapped as Beyond (request)