
    【K-Shoot Mania Skin】
           Deep Sea

  brought to you by GhettoGirl
    GitHub: GhettoGirl
    Twitter: GhettoGirl30_TV

this skin is based of Hazrd's SDVXII -infinite infection- Skin
  www.reddit.com/user/HazrdMC
available here: http://www.mediafire.com/download/3rxs7hr81sh3qr0/KSM-II+Updated.rar



How to install?

Goto your K-Shoot Mania directory and simple replace the contents
of the "img" and "se" folder with this one.
Don't forget to backup your current skin, just in case ;P


「Extras」

In the "lang" folder you find a complete Japanese translation to match
my skin. Most strings are in English even if select Japanese in the game.
Just place the text file in the "lang" folder of the game, and it becomes
available in the in-game config menu.

Enjoy!

PS: My skin is in japanese :D
