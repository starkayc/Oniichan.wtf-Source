# Introducing the kshootmania skin inspired from Cytus 2

I don't really know how to replicate make the note/laser effects to this game as I'm having a hard time with it. Other than the listed, I could say that this skin is complete.

## Difference from common skins
- I made a different texture for the BT, BT Holds, FX, and FX Holds.

## To do list:
- [ ] Course-related part of the game's skin
- [ ] Options Screen
- [ ] Note/Laser Explosions

## Extra:
You can change the difficulty images. It's available on the 'imgs/customize' folder.

### Cytus II's Difficulty Images

![Cytus Difficulties](https://i.imgur.com/dPal39Y.png)

### Sound Voltex' Difficulty Images

![Sound Voltex Difficulties](https://i.imgur.com/g6Riydl.png)

## Skin Video Preview
[You can check how this skin looks like before downloading.](https://www.youtube.com/watch?v=HcHdm5ZpaAY)
