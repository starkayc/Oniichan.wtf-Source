Bang Dream: Girls Band Party! skin for K-Shoot Mania!

If you're reading this, thank you so much for taking your time to give this a read.
This blursed (cursed + blessed) skin took me 5 days of making this.
1 1/2 day for searching for the game assets that I will need.
The rest are the building of the skin itself and testing them.

And yes, this is fully skinned (including unnecessary stuff that you will be able to find on the game) except for the actual playfield.

Thank you to the following for helping me making this skin possible to make! 

- Bandori.Party and Bestdori.com for the game assets!
- Burrito#6903 for helping me out getting the BGMs and the Sound effects that are not found on the Assets site!
- Since I really don't know how am I going to skin the playfield itself, I used rdtoi1's simplified skin elements for it.

How to install the skin:
- Delete 'cache,' 'imgs,' and the 'se' folders. Please sure back them up first before deleting them.
- Extract the contents of this archive to the same folder where you deleted folders.
- Run the game and enjoy!

Additional Options:
- If you want to use the default skin for the playfield, you may copy everything from the 'img\btdef' folder and pasting to the 'img' folder. IF you got a prompt to replace, select replace all.
- You may revert the playfield skin from the original installation, you should be able to find the 'bt from rdtoi1's skin' from the 'img' folder. Just follow the instructions from the above.

If you liked my work, consider liking my facebook gaming page and/or subscribing to my youtube channel.

fb.gg/toshiyukidomaofficial
youtube.com/arvinkent098
